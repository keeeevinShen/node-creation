# Lightsail 一键节点（Chrome 插件）

点一下，在已登录的 AWS 账号里建一台 Lightsail 实例，装好 3X-UI 和 VLESS + Reality 入站，然后打开 3X-UI 面板并自动登录。链接和二维码在面板里看。

## 安装（只做一次）

1. 解压得到 `lightsail-node-extension` 文件夹，放到一个不会删的位置。
2. Chrome 地址栏打开 `chrome://extensions`，打开右上角的「开发者模式」。
3. 点「加载已解压的扩展程序」，选这个文件夹。
4. 点工具栏的拼图图标，把「Lightsail 一键节点」固定到工具栏。

## 使用

前提只有一个：这个浏览器登录过 AWS。不用先打开 Lightsail 页面。

1. 点插件图标。
2. 选 AWS 账号（会列出当前打开的 AWS 标签页里登录着的账号；没有打开的话，就用 AWS 最近登录的那个）。
3. 选部署区域。默认跟所选账号标签页的区域一致；选「不指定」就用 AWS 控制台当前的区域。
   账号不能用某个区域时（比如新账号只开了一个区），创建前会停下并说明，不会产生费用。
4. 节点名、伪装网站和 Xray 内核用默认值即可，点「创建并部署」。
5. 之后全自动，新开的标签页左下角有进度：
   - 核对创建页上的区域，填创建实例表单并创建（Debian 12，最便宜的带公网 IPv4 套餐，美国区 $5/月）
   - 挂静态 IP `<节点名>-ip`
   - 防火墙放行 443 和面板端口（默认的 22、80 保留，80 用来给面板证书续期）
   - 关闭实例的 IPv6，改成纯 IPv4（免得访问网站时从 IPv6 出去，和 IPv4 的位置对不上）
   - 服务器自己开 BBR、安装 3X-UI、签 HTTPS 证书、换 Xray 内核、建 Reality 入站（见下面「服务器上装了什么」）
6. 约 3 分钟后，自动打开 3X-UI 面板并登录。

以后再点插件图标，「已部署的节点」里可以重新打开面板（仍然自动登录）、复制节点链接、更换 IP、复制面板登录信息。

## 更换 IP

IP 被墙了，点节点上的「更换 IP」，确认后全自动，约 3–5 分钟：

1. 在 Lightsail 控制台里解绑旧静态 IP，新建一个 `<节点名>-ip-<年月日时分>` 挂上，再删掉旧的。
2. 服务器发现公网 IP 变了，自动给新 IP 重签面板证书并重启面板（节点断几秒）。
3. 新地址上的面板能打开后，节点卡片上的 IP、链接、面板地址都换成新的。

完成后点「复制链接」，在客户端里导入新链接、删掉旧节点。链接里的密钥都没变，只有 IP 换了；面板的用户名和密码也不变。

- **0.8.0 之前部署的节点**：服务器上还没有自动重签证书的程序，要先装一次。点节点上的「复制服务器命令」，到 Lightsail → 实例 → Connect using SSH，粘贴回车，看到「已装好」就行，以后都能一键换 IP。
  IP 已经在控制台里手动换过、面板打不开的节点，装完 1–2 分钟后证书会自动换成当前 IP。
- **在控制台里手动换过 IP**：点「更换 IP」时，插件发现实例现在的 IP 和记录不一样，就不再换，直接把记录更新成现在的 IP。插件记录里的旧 IP 不去动（可能已经挪给别的实例了）。
- **旧静态 IP 没删掉**：节点照常能用，卡片上会提示。到 Lightsail → Networking 手动删掉闲置的静态 IP，闲置的按小时收费。
- 防火墙的 80 端口要开着（部署时默认保留），签证书要用。

## 服务器上装了什么

和在面板里手动建一个 VLESS + Reality 入站是同一套东西，入站的字段跟面板「添加入站」保存出来的一致，另外替你做了三件手动部署时容易漏的事：

- **Sniffing 开着**（HTTP、TLS、QUIC；不勾 Metadata Only 和 Route Only）。客户端本地的 DNS 被污染时，交给节点的是假 IP，服务器照着连会超时，表现是「显示已连接，但 Google 打不开」。开了 Sniffing，Xray 会从握手里读出真实域名，在服务器上重新解析。
- **BBR 开着**（`/etc/sysctl.d/99-bbr.conf`，重启后仍生效）。默认的 cubic 一丢包就大幅降速，国内到海外的线路上 BBR 快很多。
- **Xray 内核默认换成兼容版 v26.6.27**。3X-UI v3.11.0 自带的是 v26.10.21；Xray 从 v26.9.8 起，REALITY 服务端会拒绝握手里不带 X25519MLKEM768 的客户端。旧版小火箭、sing-box 内核的客户端（包括部分版本的 Hiddify）参数全对也连不上，服务器日志里是
  `REALITY: processed invalid connection from …: authentication failed or validation criteria not met`，改 `minClientVer` 没有用。v26.6.27 是最后一个新旧客户端都放行的版本，也是面板允许切换到的最低版本。
  - 自带的内核留了一份在 `/usr/local/x-ui/bin/xray-linux-amd64.bundled`。换了内核后 Xray 起不来的话，开机脚本会自动换回自带的。
  - 想用最新内核：部署时在「Xray 内核」里选「面板自带的最新版」，或者部署后在面板首页点 Xray 版本切换。用最新内核时，客户端要够新，握手里要带 X25519MLKEM768。
  - 以后升级 3X-UI 面板，内核会跟着变回新版，要在面板首页把 Xray 版本切回 v26.6.27。
  - 代价：v26.6.27 是 2026 年 6 月的版本，之后的修复和改动它都没有。

另外装了一个换 IP 用的小程序 `node-ip-watch`（systemd 定时器，每分钟查一次公网 IP）：公网 IP 和面板证书上的 IP 对不上时，给新 IP 重签证书并重启面板。日志在 `/var/log/node-ip-watch.log`。证书签不下来时 10 分钟后再试。

链接里的 `support-x25519mlkem768=true` 是面板导出的链接也会带的提示，Mihomo 系客户端靠它在握手里带上 X25519MLKEM768；不认识这个参数的客户端会忽略它。

### 以前部署的节点怎么补上

- Sniffing：面板 → 入站 → 编辑 443 那个入站 → 打开 Sniffing，勾 HTTP、TLS、QUIC，保存。
- 内核：面板首页 → Xray 版本 → 切换到 v26.6.27。
- BBR：浏览器 SSH 进实例，运行
  ```bash
  printf 'net.core.default_qdisc = fq\nnet.ipv4.tcp_congestion_control = bbr\n' | sudo tee /etc/sysctl.d/99-bbr.conf
  echo tcp_bbr | sudo tee /etc/modules-load.d/bbr.conf
  sudo modprobe tcp_bbr && sudo sysctl -p /etc/sysctl.d/99-bbr.conf
  ```

## 出问题时

任何一步停下，点插件图标都能看到原因和「重试」。重试从停下的地方接着做：先查实例有没有建好，建好了就接着配置，不会重复创建。部署用的标签页被不小心关掉时，点插件图标里的「继续」。

部署过程中那个标签页不用一直看着，但不要关。

- **AWS 拒绝创建**：进度里会原样显示 AWS 给的原因。常见的是 `Some names are already in use`：名字被占用，或刚删除的同名实例还没删完。等几分钟重试，或放弃后换一个节点名。
- **配额不够**：这个 AWS 账号还不允许建 Lightsail 实例，没有产生费用。到 Service Quotas → Amazon Lightsail → Instances 申请提高，或换一个账号。
- **已经有同名实例**：插件不会去动不是它创建的实例。放弃这次部署，换一个节点名。
- **打开的是 AWS 登录页**：登录后会自动继续。
- **面板迟迟没就绪**：重试会继续等。想看原因：Lightsail 控制台 → 实例 → Connect using SSH，运行
  `sudo cat /root/node-deploy.status` 和 `sudo tail -n 50 /var/log/node-deploy.log`。
  正常结果是 `ok: Xray 26.6.27, bbr`。`ok with warnings:` 后面是没做成的事，节点本身能用：
  `xray-pin-download-failed` / `xray-pin-install-failed`（内核没换成，用的是自带的新版）、
  `xray-pin-rolled-back`（换了以后 Xray 起不来，已换回自带的）、`bbr-not-enabled`。
- **面板能打开，客户端连不上**：先看服务器日志 `sudo journalctl -u x-ui --since '-30 min' --no-pager | grep REALITY | tail`。
  有 `authentication failed or validation criteria not met`，而链接里的 pbk、sid、sni 都对：是内核版本和客户端不匹配，见上面「服务器上装了什么」。
  什么都没有：客户端的连接没到服务器，检查客户端选中的是不是这个节点。
- **显示已连接，但 Google 等网站打不开**：确认入站的 Sniffing 开着（本插件建的入站默认开）。
- **换 IP 后面板一直打不开**：浏览器 SSH 进实例运行 `sudo tail -n 30 /var/log/node-ip-watch.log`。
  什么都没有：多半是 0.8.0 之前部署的节点，还没装换 IP 程序，见上面「更换 IP」。
  有 `failed: port 80 must be open`：Lightsail 防火墙把 80 关了，加回 TCP 80 后 10 分钟内会自动再签。
  也可以手动签：运行 `sudo x-ui`，选 20（SSL 证书管理）→ 6（为 IP 申请证书），IPv6 和端口直接回车。
- **AWS 控制台改版**：插件找不到按钮时会停下并说明是哪个元素，不会乱点。选择器都在 `page.js` 里。

服务器开机后会等静态 IP 最多 1 小时，所以中途出错后有充足时间重试。

## 说明

- 所有密钥和面板密码在你的浏览器里生成，存在插件的本地存储里，不会发到别处；开机脚本里含有它们，会随创建实例提交给 AWS。
- 「放弃这次部署」「放弃这次换 IP」「移除记录」只清插件里的记录，不会删除 AWS 上的资源。不用的节点要到 Lightsail 控制台删除实例和静态 IP（没挂在实例上的静态 IP 会收费）。
- 插件申请了「所有 HTTPS 网站」的权限，因为 3X-UI 面板的地址是一个事先不知道的 IP。它只在 Lightsail 控制台页面，以及它自己打开的面板标签页里运行代码。

## 文件

| 文件 | 作用 |
| --- | --- |
| `manifest.json` | 插件声明 |
| `popup.html` / `popup.js` | 点图标弹出的界面 |
| `core.js` | 生成密钥、开机脚本、节点链接、服务器上的换 IP 程序 |
| `page.js` | 在 Lightsail 页面里填表单、点按钮（部署和换 IP） |
| `content.js` | 页面和插件之间传话，等面板就绪 |
| `background.js` | 开标签页、探测面板、自动登录、保存节点记录 |
