// 后台：打开标签页、探测面板是否就绪、保存节点记录、在 3X-UI 登录页自动登录。
importScripts('core.js');

async function getJob() {
  return (await chrome.storage.local.get('job')).job || null;
}

async function getNodes() {
  return (await chrome.storage.local.get('nodes')).nodes || [];
}

function panelUrlOf(job) {
  return 'https://' + job.ip + ':' + job.creds.panelPort + '/' + job.creds.panelPath + '/';
}

// 实例 Networking 页的地址。区域和域名优先用创建时记下的，没有就从旧版本存的地址或账号域名里取
function networkingUrlOf(job) {
  var origin = job.origin || (job.instanceUrl ? new URL(job.instanceUrl).origin : '') || (job.host ? 'https://' + job.host : '');
  var region = job.region || '';
  var m;
  if (!region && job.instanceUrl && (m = /\/webapp\/([a-z]{2}(?:-[a-z]+)+-\d)\//.exec(job.instanceUrl))) region = m[1];
  if (!region && (m = /\.([a-z]{2}(?:-[a-z]+)+-\d)\.console\.aws\.amazon\.com$/.exec(origin))) region = m[1];
  if (!origin || !region) return null;
  return origin + '/lightsail/webapp/' + region + '/instances/' + encodeURIComponent(job.name) + '/networking';
}

// 打开 3X-UI 面板，并记下这个标签页，等它加载完自动登录。先记下再打开网址，保证加载完时一定查得到
async function openPanel(node) {
  var tab = await chrome.tabs.create({ url: 'about:blank' });
  await chrome.storage.local.set({ pendingLogin: { tabId: tab.id, name: node.name } });
  await chrome.tabs.update(tab.id, { url: node.panelUrl });
}

// 在 3X-UI 登录页里执行（页面自己的 JS 环境）。只提交一次，不重试，免得密码不对时反复撞
async function panelLogin(user, pass) {
  function setValue(el, value) {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    var userInput = document.querySelector('form input[autocomplete="username"]');
    var passInput = document.querySelector('form input[type="password"]');
    var submit = document.querySelector('form button[type="submit"]');
    if (userInput && passInput && submit) {
      setValue(userInput, user);
      setValue(passInput, pass);
      await new Promise(function (r) { setTimeout(r, 300); });
      submit.click();
      return 'submitted';
    }
    await new Promise(function (r) { setTimeout(r, 300); });
  }
  return 'no-form';   // 没有登录表单：多半是已经登录了
}

var loggingIn = {};   // 正在自动登录的标签页，防止同一次加载触发两遍

chrome.tabs.onUpdated.addListener(async function (tabId, info, tab) {
  if (info.status !== 'complete' || loggingIn[tabId]) return;
  loggingIn[tabId] = true;
  try {
    var pending = (await chrome.storage.local.get('pendingLogin')).pendingLogin;
    if (!pending || pending.tabId !== tabId) return;
    var node = (await getNodes()).filter(function (n) { return n.name === pending.name; })[0];
    // 只在面板自己的地址上填密码；标签页还没到面板地址时先不动
    if (!node || !tab || !tab.url || tab.url.indexOf(new URL(node.panelUrl).origin + '/') !== 0) return;
    // 页面没加载出来（比如面板正好在重启）时这一步会失败，记录保留着，刷新那个标签页会再试一次
    await chrome.scripting.executeScript({
      target: { tabId: tabId }, world: 'MAIN', func: panelLogin, args: [node.panelUser, node.panelPass]
    });
    await chrome.storage.local.remove('pendingLogin');
  } catch (e) {
    console.warn('自动登录没有执行：', e);
  } finally {
    delete loggingIn[tabId];
  }
});

var handlers = {
  whoami: async function (msg, sender) {
    return { tabId: sender.tab ? sender.tab.id : null };
  },

  // 弹窗点了「创建并部署」：开一个标签页，之后由那个页面上的 content.js 接手。
  // 先存好任务再打开网址，保证页面加载时一定读得到任务
  start: async function (msg) {
    var job = msg.job;
    var tab = await chrome.tabs.create({ url: 'about:blank' });
    job.tabId = tab.id;
    await chrome.storage.local.set({ job: job });
    await chrome.tabs.update(tab.id, { url: job.url });
    return { ok: true };
  },

  // 出错后重试：从停下的那一步接着做
  retry: async function () {
    var job = await getJob();
    if (!job) return { ok: false };
    delete job.error;
    job.attempt = (job.attempt || 0) + 1;
    // 还没确认实例建好的话，重试先回到「检查实例存不存在」，建好了就接着配置，不会重复创建
    if (job.stage === 'fill') job.stage = 'check';
    var url = networkingUrlOf(job) || job.url;
    var tab = null;
    try { tab = await chrome.tabs.get(job.tabId); } catch (e) { /* 原来的标签页已经关了 */ }
    if (!tab) tab = await chrome.tabs.create({ url: 'about:blank' });
    job.tabId = tab.id;
    await chrome.storage.local.set({ job: job });
    await chrome.tabs.update(tab.id, { url: url, active: true });
    return { ok: true };
  },

  // 面板能不能连上（证书有效、端口通）
  checkPanel: async function (msg) {
    var job = await getJob();
    if (!job || job.id !== msg.id || !job.ip) return { ok: false };
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 6000);
    try {
      await fetch(panelUrlOf(job), { signal: controller.signal, cache: 'no-store', credentials: 'omit' });
      return { ok: true };
    } catch (e) {
      return { ok: false };
    } finally {
      clearTimeout(timer);
    }
  },

  // 部署完成：存成一条节点记录，打开面板
  finish: async function (msg) {
    var job = await getJob();
    if (!job || job.id !== msg.id || job.finished) return { ok: false };
    var node = {
      name: job.name,
      ip: job.ip,
      host: job.host || '',
      link: LSN.buildLink(job.creds, job.ip),
      panelUrl: panelUrlOf(job),
      panelUser: job.creds.panelUser,
      panelPass: job.creds.panelPass,
      xrayCore: job.creds.xrayCore || '',
      createdAt: job.createdAt
    };
    var nodes = (await getNodes()).filter(function (n) { return n.name !== node.name || n.ip !== node.ip; });
    nodes.push(node);
    job.finished = true;
    job.log.push('完成。面板已在新标签页打开。');
    await chrome.storage.local.set({ nodes: nodes, job: job });
    await openPanel(node);
    return { ok: true };
  },

  openPanel: async function (msg) {
    var node = (await getNodes()).filter(function (n) { return n.name === msg.name && n.ip === msg.ip; })[0];
    if (!node) return { ok: false };
    await openPanel(node);
    return { ok: true };
  }
};

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  var handler = msg && handlers[msg.type];
  if (!handler) return false;
  handler(msg, sender).then(sendResponse, function (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); });
  return true;   // 异步回复
});
