// 在 Lightsail 控制台页面里执行部署步骤：填创建实例表单、挂静态 IP、加防火墙规则。
// 运行在页面自己的 JS 环境里（manifest 里 world: MAIN），平时什么都不做，
// 只有 content.js 发来一个部署任务时才开始。进度通过 postMessage 回报给 content.js。
(function () {
  'use strict';
  if (window.__lsNodePage) return;
  window.__lsNodePage = true;

  var CONFIG = { blueprint: 'debian_12', bundle: 'nano_3_0' };  // 收到任务后用任务里的值覆盖

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  async function waitFor(selector, timeoutMs) {
    var deadline = Date.now() + (timeoutMs || 30000);
    while (Date.now() < deadline) {
      var el = document.querySelector(selector);
      if (el) return el;
      await sleep(300);
    }
    throw new Error('页面上找不到 ' + selector + '（控制台可能改版了）');
  }

  // React 接管的输入框：要用原生 setter 赋值再派发 input 事件，直接改 .value 不生效
  function setValue(el, value, blur) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (blur) el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  async function pickRadio(value) {
    var el = await waitFor('main input[type=radio][value="' + value + '"]');
    if (el.disabled) throw new Error('选项 ' + value + ' 在这个区域不可选');
    if (!el.checked) { el.click(); await sleep(1200); }
    el = document.querySelector('main input[type=radio][value="' + value + '"]');
    if (!el || !el.checked) throw new Error('没能选中 ' + value);
  }

  var SEL = {
    launchSection: '[data-testid="launchScriptInputSection"]',
    addLaunchScript: '[data-testid="instances.labels.addLaunchScriptLabel"]',
    nameInput: '[data-testid="instance-name-input"] input',
    createButton: '[data-testid="ls.createResourceButton.instance"]',
    quotaDialog: '[data-testid="serviceQuotas.header.adjustableLimitTitle"]'
  };

  // 创建表单上当前显示的报错文字（AWS 拒绝创建时会在表单里显示一行红字）
  function visibleErrors() {
    var texts = [];
    document.querySelectorAll('main [class*="error__message"]').forEach(function (el) {
      var text = (el.innerText || '').replace(/\s+/g, ' ').trim();
      if (text && el.getClientRects().length && texts.indexOf(text) < 0) texts.push(text);
    });
    return texts;
  }

  // 点了「Create instance」之后的结果：
  //   created  页面跳到了这台实例的页面
  //   quota    弹出了配额不足
  //   rejected AWS 拒绝了，text 是它显示的原因
  //   timeout  一直没有反应（这时不能下结论，要去查实例到底有没有建出来）
  async function waitCreateOutcome(name, timeoutMs, errorsBefore) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      var quota = document.querySelector(SEL.quotaDialog);
      if (quota && quota.offsetParent) return { kind: 'quota' };
      if (!onCreatePage() && onInstancePage(name)) return { kind: 'created' };
      var fresh = visibleErrors().filter(function (text) { return errorsBefore.indexOf(text) < 0; });
      if (fresh.length) return { kind: 'rejected', text: fresh.join('；') };
      await sleep(500);
    }
    return { kind: 'timeout' };
  }

  function appPrefix() {
    var m = location.pathname.match(/^\/(lightsail|ls)\/webapp/);
    return m ? m[0] : '/lightsail/webapp';
  }
  function onCreatePage() { return /\/webapp\/create\/instance/.test(location.pathname); }

  // 填好创建实例表单，但不点「Create instance」
  async function fillCreateForm(c, log) {
    log('选择平台：Linux operating system');
    await pickRadio('LINUX_UNIX-os');
    log('选择镜像：' + CONFIG.blueprint);
    await pickRadio(CONFIG.blueprint);
    log('选择套餐：' + CONFIG.bundle);
    await pickRadio(CONFIG.bundle);

    log('填入开机脚本');
    var section = await waitFor(SEL.launchSection);
    if (!section.querySelector('textarea')) {
      (await waitFor(SEL.addLaunchScript)).click();
    }
    var textarea = await waitFor(SEL.launchSection + ' textarea');
    var script = c.launchScript;
    setValue(textarea, script);

    // 名字放最后填：换镜像时控制台会把名字改回默认值
    log('填入实例名：' + c.name);
    setValue(await waitFor(SEL.nameInput), c.name);
    await sleep(1000);

    // 逐项核对，任何一项对不上都不继续
    var checks = [
      ['镜像', document.querySelector('[data-testid="blueprintPicker"] input:checked'), CONFIG.blueprint],
      ['套餐', document.querySelector('[data-testid="bundlePicker"] input:checked'), CONFIG.bundle],
      ['实例名', document.querySelector(SEL.nameInput), c.name],
      ['开机脚本', document.querySelector(SEL.launchSection + ' textarea'), script]
    ];
    checks.forEach(function (row) {
      if (!row[1] || row[1].value !== row[2]) throw new Error(row[0] + ' 没有填成功');
    });
    var button = await waitFor(SEL.createButton);
    if (button.disabled) throw new Error('「Create instance」按钮是灰的，可能实例名重复，看一下页面上的红字');
  }

  // ---------- 实例的 Networking 页：静态 IP 和防火墙 ----------

  var NET = {
    networkingTab: 'a[data-testid="/webapp/:region/instances/:instanceName/networking"]',
    notFound: '[data-testid="ls.instanceDetail.couldNotFindInstance"]',
    attachStaticIp: '[data-testid="ls.instanceNetworkingIp.attachStaticIp"]',
    detachStaticIp: '[data-testid="staticIps.labels.detachStaticIp"]',
    staticIpName: 'input[aria-label="Input static IP name"]',
    staticIpMenu: '[data-testid="instanceNetworkingSelectStaticIpMenu"]',
    createAndAttach: '[data-testid="staticIps.labels.createAndAttach"]',
    continueButton: '[data-testid="shared.controlLabels.continue"]',
    staticIpTitle: '[data-testid="shared.resources.staticIpAddressTitle"]',
    firewallTitle: '[data-testid="instances.titles.firewall"]',
    addRule: '[data-testid="instances.labels.addRule"]',
    rulePort: '[data-testid="manage-instance-networking-port-range-input"] input',
    ruleSource0: '[data-testid="ip-address-input-0"] input',
    ruleSource1: '[data-testid="ip-address-input-1"] input',
    ruleSourceEditor: '[data-testid="source-ip-address-editor"]',
    createRule: '[data-testid="instances.labels.createRule"]'
  };

  // 当前地址是不是这个实例的页面。刚创建完时地址是 /instances/<名字>（后面没有别的），稍后才跳到 /connect
  function onInstancePage(name) {
    var m = location.pathname.match(/\/instances\/([^\/]+)/);
    return !!m && decodeURIComponent(m[1]) === name;
  }

  function onNetworkingTab() { return /\/networking$/.test(location.pathname); }

  // 区域：优先从地址里的 /webapp/<区域>/ 取，其次从控制台域名取
  function currentRegion() {
    var m = location.pathname.match(/\/webapp\/([a-z]{2}(?:-[a-z]+)+-\d)\//) ||
      location.host.match(/\.([a-z]{2}(?:-[a-z]+)+-\d)\.console\.aws\.amazon\.com$/) ||
      location.search.match(/[?&]region=([a-z]{2}(?:-[a-z]+)+-\d)/);
    return m ? m[1] : null;
  }

  function networkingUrl(name, region) {
    region = region || currentRegion();
    if (!region) return null;
    return location.origin + appPrefix() + '/' + region + '/instances/' + encodeURIComponent(name) + '/networking';
  }

  // 切到实例的 Networking 标签页并等它稳定下来。
  // 刚创建完时控制台会自己跳到 Connect 标签页，可能把我们刚点的 Networking 顶掉，所以要连续确认
  async function openNetworkingTab(name) {
    if (!onInstancePage(name)) throw new Error('当前不在实例 ' + name + ' 的页面上');
    var deadline = Date.now() + 90000;
    var stable = 0;
    while (stable < 3) {
      if (Date.now() > deadline) throw new Error('没能打开实例 ' + name + ' 的 Networking 标签页');
      if (document.querySelector(NET.notFound)) throw new Error('实例 ' + name + ' 不存在（可能已被删除）');
      if (onNetworkingTab() && document.querySelector(NET.firewallTitle)) {
        stable++;
      } else {
        stable = 0;
        var tab = document.querySelector(NET.networkingTab);
        if (tab && !onNetworkingTab()) tab.click();
      }
      await sleep(1000);
    }
  }

  // 实例到底存不存在：在它的页面上，出现标签栏就是存在，出现「找不到实例」就是不存在
  async function instanceState(name, timeoutMs) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (document.querySelector(NET.notFound)) return 'missing';
      if (document.querySelector(NET.networkingTab)) return 'exists';
      await sleep(300);
    }
    throw new Error('实例 ' + name + ' 的页面 ' + Math.round(timeoutMs / 1000) + ' 秒没有加载出来');
  }

  function readStaticIp() {
    var el = document.querySelector(NET.staticIpTitle);
    for (var i = 0; i < 4 && el; i++) {
      var m = el.innerText.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
      if (m) return m[0];
      el = el.parentElement;
    }
    return null;
  }

  // 页面上显示的实例状态（Starting / Running / …），读不到时返回空
  function shownInstanceState() {
    var main = document.querySelector('main');
    var m = main && main.innerText.match(/Instance state\s*\n?\s*([A-Za-z]+)/);
    return m ? m[1] : '';
  }

  // 账号里有没挂到实例上的闲置静态 IP 时，弹窗先出一个下拉框让选已有的 IP，
  // 最后一项才是「Create a new static IP」。选它，弹窗就变成填名字的样子
  async function pickCreateNewStaticIp(menu) {
    var dialog = menu.closest('[role="dialog"]') || document;
    function createOption() {
      return Array.prototype.filter.call(dialog.querySelectorAll('[role="option"]'), function (o) {
        return /create a new static ip/i.test(o.textContent) && o.getClientRects().length;
      })[0];
    }
    if (!createOption()) {
      (dialog.querySelector('button[aria-label="open menu"]') || menu).click();
      await sleep(800);
    }
    var option = createOption();
    if (option) option.click();
  }

  // 点「Attach static IP」直到出现填名字的弹窗。实例没到 Running 时这个按钮点了没反应，所以只在 Running 时点。
  // 等不到就返回 false，由调用方刷新页面：控制台页面上的实例状态不一定会自己更新（标签页在后台时就不更新）
  async function openStaticIpDialog(timeoutMs) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (document.querySelector(NET.staticIpName)) return true;
      var menu = document.querySelector(NET.staticIpMenu);
      if (menu) {
        await pickCreateNewStaticIp(menu);
      } else {
        var state = shownInstanceState();
        var attach = document.querySelector(NET.attachStaticIp);
        if (attach && (state === 'Running' || state === '')) attach.click();
      }
      await sleep(2500);
    }
    return !!document.querySelector(NET.staticIpName);
  }

  // 建一个静态 IP 并挂到实例上，返回 IP。已经挂过就直接读出来。弹窗一直打不开时返回 null
  async function attachStaticIp(name, dialogWaitMs) {
    if (!document.querySelector(NET.detachStaticIp)) {
      if (!(await openStaticIpDialog(dialogWaitMs))) return null;
      setValue(document.querySelector(NET.staticIpName), name + '-ip');
      await sleep(500);
      (await waitFor(NET.createAndAttach)).click();
      var deadline = Date.now() + 60000;
      while (!document.querySelector(NET.detachStaticIp)) {
        if (Date.now() > deadline) throw new Error('静态 IP 没挂上。多半是 ' + name + '-ip 这个名字已被占用：到 Lightsail → Networking 里删掉闲置的 ' + name + '-ip，再点「重试」');
        await sleep(500);
      }
      // 成功后会弹一个「Static IP created」，要点 Continue 才能继续操作页面
      for (var i = 0; i < 20; i++) {
        var cont = document.querySelector(NET.continueButton);
        if (cont && cont.offsetParent) { cont.click(); break; }
        await sleep(500);
      }
    }
    var ip = readStaticIp();
    if (!ip) throw new Error('静态 IP 已挂上，但没能从页面上读出地址');
    return ip;
  }

  // 防火墙表格里已经放行的端口
  function firewallPorts() {
    var el = document.querySelector(NET.firewallTitle);
    while (el && !el.querySelector('table')) el = el.parentElement;
    if (!el) return [];
    var ports = [];
    el.querySelectorAll('table tbody tr').forEach(function (row) {
      row.querySelectorAll('td').forEach(function (cell) {
        var text = cell.innerText.trim();
        if (/^\d+( ?- ?\d+)?$/.test(text)) ports.push(text);
      });
    });
    return ports;
  }

  // 加一条 TCP 规则，来源是任意 IPv4 和 IPv6。已经有这个端口就跳过
  async function addFirewallRule(port) {
    port = String(port);
    if (firewallPorts().indexOf(port) >= 0) return;
    if (!document.querySelector(NET.rulePort)) (await waitFor(NET.addRule)).click();
    setValue(await waitFor(NET.rulePort), port, true);
    setValue(await waitFor(NET.ruleSource0), '0.0.0.0/0', true);
    if (!document.querySelector(NET.ruleSource1)) {
      var editor = await waitFor(NET.ruleSourceEditor);
      var addSource = Array.prototype.filter.call(editor.querySelectorAll('button'), function (b) { return b.textContent.trim() === 'Add'; })[0];
      if (!addSource) throw new Error('找不到添加第二个来源地址的「Add」按钮');
      addSource.click();
    }
    setValue(await waitFor(NET.ruleSource1), '::/0', true);
    await sleep(500);
    var submit = await waitFor(NET.createRule);
    if (submit.disabled) throw new Error('「Add rule」按钮是灰的，端口 ' + port + ' 没加上');
    submit.click();
    var deadline = Date.now() + 40000;
    while (document.querySelector(NET.rulePort) || firewallPorts().indexOf(port) < 0) {
      if (Date.now() > deadline) throw new Error('提交后防火墙表格里没有出现端口 ' + port);
      await sleep(500);
    }
  }

  // ---------- 任务执行 ----------
  //
  // 一次部署分四步，进度（job.stage）存在插件里，页面刷新、跳转、重试都从存下的那一步接着走：
  //   check    打开实例页面，查这个名字的实例存不存在
  //   fill     填创建表单并点创建
  //   network  挂静态 IP、开防火墙
  //   done     AWS 这边做完了，等服务器装好（由 content.js 负责）
  // 「实例有没有建成功」只认一件事：实例页面打不打得开。不靠「点完按钮后页面有没有跳转」来猜。

  var job = null;
  var started = false;
  var box = null;
  var acks = {};
  var ackCount = 0;

  function post(type, data, ack) {
    window.postMessage({ source: 'lsn-page', type: type, data: data === undefined ? null : data, ack: ack || 0 }, location.origin);
  }

  // 页面左下角的进度框。只用 createElement / textContent
  function show(msg) {
    if (!box) {
      box = document.createElement('div');
      box.id = 'lightsail-node-status';
      box.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483647;width:360px;max-height:50vh;overflow:auto;' +
        'background:#fff;color:#16191f;border:1px solid #8d99a8;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.25);' +
        'padding:12px 14px;white-space:pre-wrap;word-break:break-all;font:13px/1.5 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;';
      var title = document.createElement('div');
      title.style.cssText = 'font-weight:600;margin-bottom:6px;';
      title.textContent = 'Lightsail 一键节点';
      box.appendChild(title);
      document.body.appendChild(box);
    }
    var line = document.createElement('div');
    line.textContent = msg;
    box.appendChild(line);
    box.scrollTop = box.scrollHeight;
  }

  function log(msg) { show(msg); post('log', msg); }

  // 把进度存进插件，存好了才算完成。紧接着要跳转页面时必须等它，否则页面一跳进度就丢了
  function save(patch) {
    Object.keys(patch).forEach(function (key) { job[key] = patch[key]; });
    return new Promise(function (resolve) {
      var n = ++ackCount;
      acks[n] = resolve;
      post('update', patch, n);
      setTimeout(resolve, 5000);
    });
  }

  function setStage(stage, extra) {
    var patch = extra || {};
    patch.stage = stage;
    patch.step = (job.step || 0) + 1;
    return save(patch);
  }

  async function fail(msg, extra) {
    log('出错：' + msg);
    var patch = extra || {};
    patch.error = msg;
    await save(patch);
  }

  // 同一步里某个跳转只做一次，避免页面来回跳
  function once(key) {
    key = 'lsn-once-' + job.id + '-' + (job.attempt || 0) + '-' + (job.step || 0) + '-' + key;
    try {
      if (sessionStorage.getItem(key)) return false;
      sessionStorage.setItem(key, '1');
    } catch (e) { /* 存不了就当第一次 */ }
    return true;
  }

  // 这一步里已经刷新过几次页面（存在标签页里，刷新后还在）；传入数字时改成这个数
  function refreshCount(value) {
    var key = 'lsn-refresh-' + job.id + '-' + (job.attempt || 0);
    try {
      if (value !== undefined) sessionStorage.setItem(key, String(value));
      return parseInt(sessionStorage.getItem(key) || '0', 10) || 0;
    } catch (e) { return 0; }
  }

  function createUrl() { return location.origin + appPrefix() + '/create/instance'; }

  function here() { return { region: currentRegion(), origin: location.origin }; }

  // 以下三个函数返回 true 表示这一步做完了、可以接着做下一步；返回 false 表示页面要跳转或已经报错

  async function stageCheck() {
    if (!onInstancePage(job.name)) {
      var target = networkingUrl(job.name, job.region);
      if (!target) { await fail('看不出当前控制台是哪个区域，没法检查实例'); return false; }
      if (!once('to-instance')) { await fail('没能打开实例 ' + job.name + ' 的页面'); return false; }
      location.assign(target);
      return false;
    }
    var state = await instanceState(job.name, 60000);
    if (state === 'exists') {
      if (!job.createClicked) {
        await fail('这个账号的 ' + currentRegion() + ' 区域里已经有一台叫 ' + job.name + ' 的实例，不是这次部署创建的，所以没有动它。' +
          '请点「放弃这次部署」，换一个节点名再来。');
        return false;
      }
      log('实例 ' + job.name + ' 已经建好，接着配置');
      await setStage('network', here());
      return true;
    }
    if (job.createClicked) {
      await fail('点过创建，但实例 ' + job.name + ' 没有建出来，没有产生费用。点「重试」会重新创建。', { createClicked: false });
      return false;
    }
    log('账号 ' + location.host.split('.')[0].split('-')[0] + ' · ' + currentRegion() + '：没有叫 ' + job.name + ' 的实例，开始创建');
    await setStage('fill', here());
    location.assign(createUrl());
    return false;
  }

  async function stageFill() {
    if (!onCreatePage()) {
      if (!once('to-create')) { await fail('没能打开创建实例页面'); return false; }
      location.assign(createUrl());
      return false;
    }
    await waitFor('[data-testid="platformPicker"]', 90000);
    await fillCreateForm(job, log);
    var errorsBefore = visibleErrors();
    await save({ createClicked: true });
    (await waitFor(SEL.createButton)).click();
    log('已点击 Create instance，等待 AWS 响应…');
    var outcome = await waitCreateOutcome(job.name, 120000, errorsBefore);
    if (outcome.kind === 'created') {
      log('实例已创建');
      await setStage('network', here());
      return true;
    }
    if (outcome.kind === 'quota') {
      await fail('这个账号的 Lightsail 实例配额不够，没有创建，也没有产生费用。' +
        '到 Service Quotas → Amazon Lightsail → Instances 申请提高配额后点「重试」，或放弃后换一个账号。', { createClicked: false });
      return false;
    }
    if (outcome.kind === 'rejected') {
      var hint = /already in use/i.test(outcome.text)
        ? '（这个名字已被占用：可能有同名实例，或刚删除的同名实例还没删完。等几分钟点「重试」，或放弃后换一个节点名。）' : '';
      await fail('AWS 没有创建实例，没有产生费用。它给的原因：' + outcome.text + hint, { createClicked: false });
      return false;
    }
    log('2 分钟了控制台还没有反应，直接去查实例有没有建出来…');
    await setStage('check');
    location.assign(networkingUrl(job.name, job.region));
    return false;
  }

  async function stageNetwork() {
    if (!onInstancePage(job.name)) {
      var target = networkingUrl(job.name, job.region);
      if (!target || !once('to-instance')) { await fail('没能打开实例 ' + job.name + ' 的页面'); return false; }
      location.assign(target);
      return false;
    }
    await openNetworkingTab(job.name);
    if (!refreshCount()) log('挂静态 IP：' + job.name + '-ip（要等实例开机，约 1 分钟）');
    var ip = await attachStaticIp(job.name, 25000);
    if (!ip) {
      // 弹窗打不开：页面上的实例状态没更新。刷新页面拿最新状态再试，刷新后会自动从这一步接着做
      var n = refreshCount() + 1;
      if (n > 24) {
        await fail('等了十几分钟，实例 ' + job.name + ' 的页面上一直不能挂静态 IP（页面显示的状态：' + (shownInstanceState() || '读不到') + '）。' +
          '到 Lightsail 里看一下这台实例是否正常，再点「重试」。');
        return false;
      }
      refreshCount(n);
      log('实例状态：' + (shownInstanceState() || '读不到') + '，还不能挂静态 IP，刷新页面再试（第 ' + n + ' 次）');
      location.reload();
      return false;
    }
    await save({ ip: ip });
    log('静态 IP：' + ip);
    log('防火墙放行 ' + job.proxyPort + '（节点）');
    await addFirewallRule(job.proxyPort);
    log('防火墙放行 ' + job.panelPort + '（3X-UI 面板）');
    await addFirewallRule(job.panelPort);
    log('AWS 这边配置完成。服务器正在安装 3X-UI，装好后会自动打开面板并登录（约 2 分钟）。');
    await setStage('done');
    return true;
  }

  async function run() {
    try {
      if (job.stage === 'check' && !(await stageCheck())) return;
      if (job.stage === 'fill' && !(await stageFill())) return;
      if (job.stage === 'network') await stageNetwork();
    } catch (e) {
      await fail(e.message);
    }
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window || !ev.data || ev.data.source !== 'lsn-ext') return;
    if (ev.data.type === 'job' && !started) {
      started = true;
      job = ev.data.data;
      CONFIG.blueprint = job.blueprint;
      CONFIG.bundle = job.bundle;
      run();
    }
    if (ev.data.type === 'ack' && acks[ev.data.data]) { acks[ev.data.data](); delete acks[ev.data.data]; }
    if (ev.data.type === 'status') show(ev.data.data);
  });
  post('ready');
})();
