// 在 Lightsail 控制台页面里执行部署步骤：填创建实例表单、挂静态 IP、加防火墙规则；
// 换 IP 时解绑旧静态 IP、挂上新的、删掉旧的。
// 运行在页面自己的 JS 环境里（manifest 里 world: MAIN），平时什么都不做，
// 只有 content.js 发来一个部署任务时才开始。进度通过 postMessage 回报给 content.js。
(function () {
  'use strict';
  if (window.__lsNodePage) return;
  window.__lsNodePage = true;

  var CONFIG = { blueprint: 'debian_12', bundle: 'nano_3_0' };  // 收到任务后用任务里的值覆盖

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  async function waitFor(selector, timeoutMs) {
    var deadline = Date.now() + (timeoutMs || 30000);
    while (Date.now() < deadline) {
      var el = document.querySelector(selector);
      if (el) return el;
      await sleep(300);
    }
    throw new Error('页面上找不到 ' + selector + '（控制台可能改版了）');
  }

  // React 接管的输入框：要用原生 setter 赋值再派发 input 事件，直接改 .value 不生效
  function setValue(el, value, blur) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    if (blur) el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  async function pickRadio(value) {
    var el = await waitFor('main input[type=radio][value="' + value + '"]');
    if (el.disabled) throw new Error('选项 ' + value + ' 在这个区域不可选');
    if (!el.checked) { el.click(); await sleep(1200); }
    el = document.querySelector('main input[type=radio][value="' + value + '"]');
    if (!el || !el.checked) throw new Error('没能选中 ' + value);
  }

  var SEL = {
    launchSection: '[data-testid="launchScriptInputSection"]',
    addLaunchScript: '[data-testid="instances.labels.addLaunchScriptLabel"]',
    nameInput: '[data-testid="instance-name-input"] input',
    createButton: '[data-testid="ls.createResourceButton.instance"]',
    quotaDialog: '[data-testid="serviceQuotas.header.adjustableLimitTitle"]'
  };

  // 创建表单上当前显示的报错文字（AWS 拒绝创建时会在表单里显示一行红字）
  function visibleErrors() {
    var texts = [];
    document.querySelectorAll('main [class*="error__message"]').forEach(function (el) {
      var text = (el.innerText || '').replace(/\s+/g, ' ').trim();
      if (text && el.getClientRects().length && texts.indexOf(text) < 0) texts.push(text);
    });
    return texts;
  }

  // 点了「Create instance」之后的结果：
  //   created  页面跳到了这台实例的页面
  //   quota    弹出了配额不足
  //   rejected AWS 拒绝了，text 是它显示的原因
  //   timeout  一直没有反应（这时不能下结论，要去查实例到底有没有建出来）
  async function waitCreateOutcome(name, timeoutMs, errorsBefore) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      var quota = document.querySelector(SEL.quotaDialog);
      if (quota && quota.offsetParent) return { kind: 'quota' };
      if (!onCreatePage() && onInstancePage(name)) return { kind: 'created' };
      var fresh = visibleErrors().filter(function (text) { return errorsBefore.indexOf(text) < 0; });
      if (fresh.length) return { kind: 'rejected', text: fresh.join('；') };
      await sleep(500);
    }
    return { kind: 'timeout' };
  }

  function appPrefix() {
    var m = location.pathname.match(/^\/(lightsail|ls)\/webapp/);
    return m ? m[0] : '/lightsail/webapp';
  }
  function onCreatePage() { return /\/webapp\/create\/instance/.test(location.pathname); }

  // 创建页「Instance location」里显示的区域，从可用区写法 (us-east-2a) 里取，读不到返回 null
  function shownCreateRegion() {
    var main = document.querySelector('main');
    var m = main && main.innerText.match(/\(([a-z]{2}(?:-[a-z]+)+-\d)[a-z]\)/);
    return m ? m[1] : null;
  }

  // 指定了区域时，创建前核对创建页上的区域，对不上就不创建
  async function checkCreateRegion(c, log) {
    if (!c.region) return;
    var shown = null;
    for (var i = 0; i < 20 && !shown; i++) {   // 区域那一栏可能比表单晚出来，最多等 10 秒
      shown = shownCreateRegion();
      if (!shown) await sleep(500);
    }
    if (!shown) { log('页面上读不到区域，按地址里的 ' + c.region + ' 创建'); return; }
    if (shown !== c.region) {
      throw new Error('创建页显示的区域是 ' + shown + '，不是选的 ' + c.region + '，没有创建。' +
        '可能这个账号不能用 ' + c.region + '，换一个区域再来');
    }
    log('区域：' + shown);
  }

  // 填好创建实例表单，但不点「Create instance」
  async function fillCreateForm(c, log) {
    await checkCreateRegion(c, log);
    log('选择平台：Linux operating system');
    await pickRadio('LINUX_UNIX-os');
    log('选择镜像：' + CONFIG.blueprint);
    await pickRadio(CONFIG.blueprint);
    log('选择套餐：' + CONFIG.bundle);
    await pickRadio(CONFIG.bundle);

    log('填入开机脚本');
    var section = await waitFor(SEL.launchSection);
    if (!section.querySelector('textarea')) {
      (await waitFor(SEL.addLaunchScript)).click();
    }
    var textarea = await waitFor(SEL.launchSection + ' textarea');
    var script = c.launchScript;
    setValue(textarea, script);

    // 名字放最后填：换镜像时控制台会把名字改回默认值
    log('填入实例名：' + c.name);
    setValue(await waitFor(SEL.nameInput), c.name);
    await sleep(1000);

    // 逐项核对，任何一项对不上都不继续
    var checks = [
      ['镜像', document.querySelector('[data-testid="blueprintPicker"] input:checked'), CONFIG.blueprint],
      ['套餐', document.querySelector('[data-testid="bundlePicker"] input:checked'), CONFIG.bundle],
      ['实例名', document.querySelector(SEL.nameInput), c.name],
      ['开机脚本', document.querySelector(SEL.launchSection + ' textarea'), script]
    ];
    checks.forEach(function (row) {
      if (!row[1] || row[1].value !== row[2]) throw new Error(row[0] + ' 没有填成功');
    });
    var button = await waitFor(SEL.createButton);
    if (button.disabled) throw new Error('「Create instance」按钮是灰的，可能实例名重复，看一下页面上的红字');
  }

  // ---------- 实例的 Networking 页：静态 IP 和防火墙 ----------

  var NET = {
    networkingTab: 'a[data-testid="/webapp/:region/instances/:instanceName/networking"]',
    notFound: '[data-testid="ls.instanceDetail.couldNotFindInstance"]',
    attachStaticIp: '[data-testid="ls.instanceNetworkingIp.attachStaticIp"]',
    detachStaticIp: '[data-testid="staticIps.labels.detachStaticIp"]',
    staticIpName: 'input[aria-label="Input static IP name"]',
    staticIpMenu: '[data-testid="instanceNetworkingSelectStaticIpMenu"]',
    createAndAttach: '[data-testid="staticIps.labels.createAndAttach"]',
    continueButton: '[data-testid="shared.controlLabels.continue"]',
    staticIpTitle: '[data-testid="shared.resources.staticIpAddressTitle"]',
    firewallTitle: '[data-testid="instances.titles.firewall"]',
    disableIpv6: '[data-testid="instances.labels.disableIpv6Networking"]',
    enableIpv6: '[data-testid="instances.labels.enableIpv6Networking"]',
    confirmDisable: '[role="dialog"] [data-testid="shared.controlLabels.confirmDisable"]',
    addRule: '[data-testid="instances.labels.addRule"]',
    rulePort: '[data-testid="manage-instance-networking-port-range-input"] input',
    ruleSource0: '[data-testid="ip-address-input-0"] input',
    ruleSource1: '[data-testid="ip-address-input-1"] input',
    ruleSourceEditor: '[data-testid="source-ip-address-editor"]',
    createRule: '[data-testid="instances.labels.createRule"]'
  };

  // 当前地址是不是这个实例的页面。刚创建完时地址是 /instances/<名字>（后面没有别的），稍后才跳到 /connect
  function onInstancePage(name) {
    var m = location.pathname.match(/\/instances\/([^\/]+)/);
    return !!m && decodeURIComponent(m[1]) === name;
  }

  function onNetworkingTab() { return /\/networking$/.test(location.pathname); }

  // 区域：优先从地址里的 /webapp/<区域>/ 取，其次从控制台域名取
  function currentRegion() {
    var m = location.pathname.match(/\/webapp\/([a-z]{2}(?:-[a-z]+)+-\d)\//) ||
      location.host.match(/\.([a-z]{2}(?:-[a-z]+)+-\d)\.console\.aws\.amazon\.com$/) ||
      location.search.match(/[?&]region=([a-z]{2}(?:-[a-z]+)+-\d)/);
    return m ? m[1] : null;
  }

  function networkingUrl(name, region) {
    region = region || currentRegion();
    if (!region) return null;
    return location.origin + appPrefix() + '/' + region + '/instances/' + encodeURIComponent(name) + '/networking';
  }

  // 切到实例的 Networking 标签页并等它稳定下来。
  // 刚创建完时控制台会自己跳到 Connect 标签页，可能把我们刚点的 Networking 顶掉，所以要连续确认
  async function openNetworkingTab(name) {
    if (!onInstancePage(name)) throw new Error('当前不在实例 ' + name + ' 的页面上');
    var deadline = Date.now() + 90000;
    var stable = 0;
    while (stable < 3) {
      if (Date.now() > deadline) throw new Error('没能打开实例 ' + name + ' 的 Networking 标签页');
      if (document.querySelector(NET.notFound)) throw new Error('实例 ' + name + ' 不存在（可能已被删除）');
      if (onNetworkingTab() && document.querySelector(NET.firewallTitle)) {
        stable++;
      } else {
        stable = 0;
        var tab = document.querySelector(NET.networkingTab);
        if (tab && !onNetworkingTab()) tab.click();
      }
      await sleep(1000);
    }
  }

  // 实例到底存不存在：在它的页面上，出现标签栏就是存在，出现「找不到实例」就是不存在
  async function instanceState(name, timeoutMs) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (document.querySelector(NET.notFound)) return 'missing';
      if (document.querySelector(NET.networkingTab)) return 'exists';
      await sleep(300);
    }
    throw new Error('实例 ' + name + ' 的页面 ' + Math.round(timeoutMs / 1000) + ' 秒没有加载出来');
  }

  function readStaticIp() {
    var el = document.querySelector(NET.staticIpTitle);
    for (var i = 0; i < 4 && el; i++) {
      var m = el.innerText.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
      if (m) return m[0];
      el = el.parentElement;
    }
    return null;
  }

  // 页面上显示的实例状态（Starting / Running / …），读不到时返回空
  function shownInstanceState() {
    var main = document.querySelector('main');
    var m = main && main.innerText.match(/Instance state\s*\n?\s*([A-Za-z]+)/);
    return m ? m[1] : '';
  }

  // 账号里有没挂到实例上的闲置静态 IP 时，弹窗先出一个下拉框让选已有的 IP，
  // 最后一项才是「Create a new static IP」。选它，弹窗就变成填名字的样子
  async function pickCreateNewStaticIp(menu) {
    var dialog = menu.closest('[role="dialog"]') || document;
    function createOption() {
      return Array.prototype.filter.call(dialog.querySelectorAll('[role="option"]'), function (o) {
        return /create a new static ip/i.test(o.textContent) && o.getClientRects().length;
      })[0];
    }
    if (!createOption()) {
      (dialog.querySelector('button[aria-label="open menu"]') || menu).click();
      await sleep(800);
    }
    var option = createOption();
    if (option) option.click();
  }

  // 点「Attach static IP」直到出现填名字的弹窗。实例没到 Running 时这个按钮点了没反应，所以只在 Running 时点。
  // 等不到就返回 false，由调用方刷新页面：控制台页面上的实例状态不一定会自己更新（标签页在后台时就不更新）
  async function openStaticIpDialog(timeoutMs) {
    var deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (document.querySelector(NET.staticIpName)) return true;
      var menu = document.querySelector(NET.staticIpMenu);
      if (menu) {
        await pickCreateNewStaticIp(menu);
      } else {
        var state = shownInstanceState();
        var attach = document.querySelector(NET.attachStaticIp);
        if (attach && (state === 'Running' || state === '')) attach.click();
      }
      await sleep(2500);
    }
    return !!document.querySelector(NET.staticIpName);
  }

  // 建一个叫 ipName 的静态 IP 并挂到实例上，返回 IP。已经挂过就直接读出来。弹窗一直打不开时返回 null
  async function attachStaticIp(ipName, dialogWaitMs) {
    if (!document.querySelector(NET.detachStaticIp)) {
      if (!(await openStaticIpDialog(dialogWaitMs))) return null;
      setValue(document.querySelector(NET.staticIpName), ipName);
      await sleep(500);
      (await waitFor(NET.createAndAttach)).click();
      var deadline = Date.now() + 60000;
      while (!document.querySelector(NET.detachStaticIp)) {
        if (Date.now() > deadline) {
          throw new Error('静态 IP 没挂上。可能是 ' + ipName + ' 这个名字已被占用，或这个区域的静态 IP 已经有 5 个（上限）：' +
            '到 Lightsail → Networking 里删掉不用的静态 IP，再点「重试」');
        }
        await sleep(500);
      }
      // 成功后会弹一个「Static IP created」，要点 Continue 才能继续操作页面
      for (var i = 0; i < 20; i++) {
        var cont = document.querySelector(NET.continueButton);
        if (cont && cont.offsetParent) { cont.click(); break; }
        await sleep(500);
      }
    }
    var ip = readStaticIp();
    if (!ip) throw new Error('静态 IP 已挂上，但没能从页面上读出地址');
    return ip;
  }

  // 防火墙表格里已经放行的端口
  function firewallPorts() {
    var el = document.querySelector(NET.firewallTitle);
    while (el && !el.querySelector('table')) el = el.parentElement;
    if (!el) return [];
    var ports = [];
    el.querySelectorAll('table tbody tr').forEach(function (row) {
      row.querySelectorAll('td').forEach(function (cell) {
        var text = cell.innerText.trim();
        if (/^\d+( ?- ?\d+)?$/.test(text)) ports.push(text);
      });
    });
    return ports;
  }

  // 加一条 TCP 规则，来源是任意 IPv4 和 IPv6。已经有这个端口就跳过
  async function addFirewallRule(port) {
    port = String(port);
    if (firewallPorts().indexOf(port) >= 0) return;
    if (!document.querySelector(NET.rulePort)) (await waitFor(NET.addRule)).click();
    setValue(await waitFor(NET.rulePort), port, true);
    setValue(await waitFor(NET.ruleSource0), '0.0.0.0/0', true);
    if (!document.querySelector(NET.ruleSource1)) {
      var editor = await waitFor(NET.ruleSourceEditor);
      var addSource = Array.prototype.filter.call(editor.querySelectorAll('button'), function (b) { return b.textContent.trim() === 'Add'; })[0];
      if (!addSource) throw new Error('找不到添加第二个来源地址的「Add」按钮');
      addSource.click();
    }
    setValue(await waitFor(NET.ruleSource1), '::/0', true);
    await sleep(500);
    var submit = await waitFor(NET.createRule);
    if (submit.disabled) throw new Error('「Add rule」按钮是灰的，端口 ' + port + ' 没加上');
    submit.click();
    var deadline = Date.now() + 40000;
    while (document.querySelector(NET.rulePort) || firewallPorts().indexOf(port) < 0) {
      if (Date.now() > deadline) throw new Error('提交后防火墙表格里没有出现端口 ' + port);
      await sleep(500);
    }
  }

  // 关掉实例的 IPv6，变成纯 IPv4：避免访问网站时从 IPv6 出去，和 IPv4 的位置对不上。已经关了就跳过
  async function disableIpv6() {
    if (document.querySelector(NET.enableIpv6)) return;
    (await waitFor(NET.disableIpv6)).click();
    var deadline = Date.now() + 60000;
    while (!document.querySelector(NET.enableIpv6)) {
      if (Date.now() > deadline) throw new Error('关 IPv6 后 60 秒页面上没出现「Enable IPv6 networking」，看一下实例的 Networking 页');
      var confirm = document.querySelector(NET.confirmDisable);
      if (confirm && confirm.getClientRects().length) confirm.click();   // 确认框，勾过「不再提示」时没有
      await sleep(1000);
    }
  }

  // ---------- 换 IP：解绑、删除静态 IP ----------
  // 这两步的按钮没有固定的 data-testid 可用，按页面上的文字找（插件按英文控制台写）

  function textOf(el) { return (el.textContent || '').replace(/\s+/g, ' ').trim(); }

  function visible(el) { return el.getClientRects().length > 0; }

  // root 里文字符合 re 的可见按钮或菜单项
  function findButtons(root, re) {
    return Array.prototype.filter.call(root.querySelectorAll('button, [role="menuitem"], [role="option"]'), function (b) {
      return re.test(textOf(b)) && visible(b) && !b.disabled;
    });
  }

  // 正在显示、内容符合 about 的确认框里，文字符合 re 的按钮。说的不是这件事的确认框一律不点
  function confirmButton(about, re) {
    var dialogs = Array.prototype.filter.call(document.querySelectorAll('[role="dialog"]'), function (d) {
      return visible(d) && about.test(d.textContent || '');
    });
    for (var i = 0; i < dialogs.length; i++) {
      var button = findButtons(dialogs[i], re)[0];
      if (button) return button;
    }
    return null;
  }

  // 把实例上的静态 IP 解绑。解绑后实例先拿到一个临时公网 IP，节点要等新静态 IP 挂上才能用
  async function detachStaticIp() {
    (await waitFor(NET.detachStaticIp)).click();
    var deadline = Date.now() + 60000;
    while (document.querySelector(NET.detachStaticIp) || !document.querySelector(NET.attachStaticIp)) {
      if (Date.now() > deadline) throw new Error('点了解绑静态 IP，60 秒后页面上还没出现「Attach static IP」，看一下实例的 Networking 页');
      var confirm = confirmButton(/static ip|detach/i, /^(yes,?\s*)?detach$/i) || findButtons(document, /^yes,?\s*detach$/i)[0];
      if (confirm) confirm.click();
      await sleep(1000);
    }
  }

  function onNetworkingHome() { return /\/webapp\/home\/networking/.test(location.pathname); }

  function homeUrl(tab) { return location.origin + appPrefix() + '/home/' + tab; }

  function ipsIn(text) { return text.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g) || []; }

  // 一块区域里的「⋮」操作菜单按钮
  function actionsButtonIn(el) {
    return Array.prototype.filter.call(el.querySelectorAll('button'), function (b) {
      var label = (b.getAttribute('aria-label') || '') + ' ' + textOf(b);
      return /action|menu|more|option|⋮/i.test(label) && visible(b);
    })[0] || null;
  }

  // Networking 页上显示着这个 IP 的静态 IP 卡片和它的「⋮」按钮。
  // 从写着这个 IP 的文字往外找，找到带操作按钮、且不含别的 IP 的最小一块；找不到返回 null
  function staticIpCard(ip) {
    var walker = document.createTreeWalker(document.querySelector('main') || document.body, NodeFilter.SHOW_TEXT);
    var node;
    while ((node = walker.nextNode())) {
      if (ipsIn(node.textContent).indexOf(ip) < 0) continue;
      for (var el = node.parentElement; el && el !== document.body; el = el.parentElement) {
        var others = ipsIn(el.innerText || '').filter(function (x) { return x !== ip; });
        if (others.length) break;   // 已经包进别的 IP 了，范围太大
        var menu = actionsButtonIn(el);
        if (menu) return { card: el, menu: menu };
      }
    }
    return null;
  }

  // 在 Networking 页上删除显示着这个 IP 的静态 IP。
  // 返回 'deleted'；页面上一直找不到这个 IP 时返回 'not-found'（可能已经删掉了）
  async function deleteStaticIp(ip) {
    var found = null;
    var deadline = Date.now() + 30000;
    while (!(found = staticIpCard(ip))) {
      if (Date.now() > deadline) return 'not-found';
      await sleep(500);
    }
    found.menu.click();
    await sleep(800);
    var item = findButtons(document, /^delete$/i).filter(function (b) { return b !== found.menu; })[0];
    if (!item) throw new Error('打开了静态 IP ' + ip + ' 的「⋮」菜单，但里面没有「Delete」');
    item.click();
    deadline = Date.now() + 60000;
    while (staticIpCard(ip)) {
      if (Date.now() > deadline) throw new Error('点了删除，60 秒后静态 IP ' + ip + ' 还在页面上');
      var confirm = confirmButton(/static ip/i, /^(yes,?\s*)?delete$/i) || findButtons(document, /^yes,?\s*delete$/i)[0];
      if (confirm) confirm.click();
      await sleep(1000);
    }
    return 'deleted';
  }

  // ---------- 任务执行 ----------
  //
  // 一次部署分四步，进度（job.stage）存在插件里，页面刷新、跳转、重试都从存下的那一步接着走：
  //   check    打开实例页面，查这个名字的实例存不存在
  //   fill     填创建表单并点创建
  //   network  挂静态 IP、开防火墙
  //   done     AWS 这边做完了，等服务器装好（由 content.js 负责）
  // 「实例有没有建成功」只认一件事：实例页面打不打得开。不靠「点完按钮后页面有没有跳转」来猜。

  var job = null;
  var started = false;
  var box = null;
  var acks = {};
  var ackCount = 0;

  function post(type, data, ack) {
    window.postMessage({ source: 'lsn-page', type: type, data: data === undefined ? null : data, ack: ack || 0 }, location.origin);
  }

  // 页面左下角的进度框。只用 createElement / textContent
  function show(msg) {
    if (!box) {
      box = document.createElement('div');
      box.id = 'lightsail-node-status';
      box.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483647;width:360px;max-height:50vh;overflow:auto;' +
        'background:#fff;color:#16191f;border:1px solid #8d99a8;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.25);' +
        'padding:12px 14px;white-space:pre-wrap;word-break:break-all;font:13px/1.5 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;';
      var title = document.createElement('div');
      title.style.cssText = 'font-weight:600;margin-bottom:6px;';
      title.textContent = 'Lightsail 一键节点';
      box.appendChild(title);
      document.body.appendChild(box);
    }
    var line = document.createElement('div');
    line.textContent = msg;
    box.appendChild(line);
    box.scrollTop = box.scrollHeight;
  }

  function log(msg) { show(msg); post('log', msg); }

  // 把进度存进插件，存好了才算完成。紧接着要跳转页面时必须等它，否则页面一跳进度就丢了
  function save(patch) {
    Object.keys(patch).forEach(function (key) { job[key] = patch[key]; });
    return new Promise(function (resolve) {
      var n = ++ackCount;
      acks[n] = resolve;
      post('update', patch, n);
      setTimeout(resolve, 5000);
    });
  }

  function setStage(stage, extra) {
    var patch = extra || {};
    patch.stage = stage;
    patch.step = (job.step || 0) + 1;
    return save(patch);
  }

  async function fail(msg, extra) {
    log('出错：' + msg);
    var patch = extra || {};
    patch.error = msg;
    await save(patch);
  }

  // 同一步里某个跳转只做一次，避免页面来回跳
  function once(key) {
    key = 'lsn-once-' + job.id + '-' + (job.attempt || 0) + '-' + (job.step || 0) + '-' + key;
    try {
      if (sessionStorage.getItem(key)) return false;
      sessionStorage.setItem(key, '1');
    } catch (e) { /* 存不了就当第一次 */ }
    return true;
  }

  // 这一步里已经刷新过几次页面（存在标签页里，刷新后还在）；传入数字时改成这个数
  function refreshCount(value) {
    var key = 'lsn-refresh-' + job.id + '-' + (job.attempt || 0);
    try {
      if (value !== undefined) sessionStorage.setItem(key, String(value));
      return parseInt(sessionStorage.getItem(key) || '0', 10) || 0;
    } catch (e) { return 0; }
  }

  // 创建页地址，有指定区域时带上 ?region=，创建页会按这个区域显示
  function createUrl() {
    var url = location.origin + appPrefix() + '/create/instance';
    if (job.region) url += '?region=' + job.region;
    return url;
  }

  function here() { return { region: currentRegion(), origin: location.origin }; }

  // 以下三个函数返回 true 表示这一步做完了、可以接着做下一步；返回 false 表示页面要跳转或已经报错

  async function stageCheck() {
    if (!onInstancePage(job.name)) {
      var target = networkingUrl(job.name, job.region);
      if (!target) { await fail('看不出当前控制台是哪个区域，没法检查实例'); return false; }
      if (!once('to-instance')) { await fail('没能打开实例 ' + job.name + ' 的页面'); return false; }
      location.assign(target);
      return false;
    }
    var state = await instanceState(job.name, 60000);
    if (state === 'exists') {
      if (!job.createClicked) {
        await fail('这个账号的 ' + currentRegion() + ' 区域里已经有一台叫 ' + job.name + ' 的实例，不是这次部署创建的，所以没有动它。' +
          '请点「放弃这次部署」，换一个节点名再来。');
        return false;
      }
      log('实例 ' + job.name + ' 已经建好，接着配置');
      await setStage('network', here());
      return true;
    }
    if (job.createClicked) {
      await fail('点过创建，但实例 ' + job.name + ' 没有建出来，没有产生费用。点「重试」会重新创建。', { createClicked: false });
      return false;
    }
    log('账号 ' + location.host.split('.')[0].split('-')[0] + ' · ' + currentRegion() + '：没有叫 ' + job.name + ' 的实例，开始创建');
    await setStage('fill', here());
    location.assign(createUrl());
    return false;
  }

  async function stageFill() {
    if (!onCreatePage()) {
      if (!once('to-create')) { await fail('没能打开创建实例页面'); return false; }
      location.assign(createUrl());
      return false;
    }
    await waitFor('[data-testid="platformPicker"]', 90000);
    await fillCreateForm(job, log);
    var errorsBefore = visibleErrors();
    await save({ createClicked: true });
    (await waitFor(SEL.createButton)).click();
    log('已点击 Create instance，等待 AWS 响应…');
    var outcome = await waitCreateOutcome(job.name, 120000, errorsBefore);
    if (outcome.kind === 'created') {
      log('实例已创建');
      await setStage('network', here());
      return true;
    }
    if (outcome.kind === 'quota') {
      await fail('这个账号的 Lightsail 实例配额不够，没有创建，也没有产生费用。' +
        '到 Service Quotas → Amazon Lightsail → Instances 申请提高配额后点「重试」，或放弃后换一个账号。', { createClicked: false });
      return false;
    }
    if (outcome.kind === 'rejected') {
      var hint = /already in use/i.test(outcome.text)
        ? '（这个名字已被占用：可能有同名实例，或刚删除的同名实例还没删完。等几分钟点「重试」，或放弃后换一个节点名。）' : '';
      await fail('AWS 没有创建实例，没有产生费用。它给的原因：' + outcome.text + hint, { createClicked: false });
      return false;
    }
    log('2 分钟了控制台还没有反应，直接去查实例有没有建出来…');
    await setStage('check');
    location.assign(networkingUrl(job.name, job.region));
    return false;
  }

  async function stageNetwork() {
    if (!onInstancePage(job.name)) {
      var target = networkingUrl(job.name, job.region);
      if (!target || !once('to-instance')) { await fail('没能打开实例 ' + job.name + ' 的页面'); return false; }
      location.assign(target);
      return false;
    }
    await openNetworkingTab(job.name);
    if (!refreshCount()) log('挂静态 IP：' + job.name + '-ip（要等实例开机，约 1 分钟）');
    var ip = await attachStaticIp(job.name + '-ip', 25000);
    if (!ip) {
      // 弹窗打不开：页面上的实例状态没更新。刷新页面拿最新状态再试，刷新后会自动从这一步接着做
      var n = refreshCount() + 1;
      if (n > 24) {
        await fail('等了十几分钟，实例 ' + job.name + ' 的页面上一直不能挂静态 IP（页面显示的状态：' + (shownInstanceState() || '读不到') + '）。' +
          '到 Lightsail 里看一下这台实例是否正常，再点「重试」。');
        return false;
      }
      refreshCount(n);
      log('实例状态：' + (shownInstanceState() || '读不到') + '，还不能挂静态 IP，刷新页面再试（第 ' + n + ' 次）');
      location.reload();
      return false;
    }
    await save({ ip: ip });
    log('静态 IP：' + ip);
    log('防火墙放行 ' + job.proxyPort + '（节点）');
    await addFirewallRule(job.proxyPort);
    log('防火墙放行 ' + job.panelPort + '（3X-UI 面板）');
    await addFirewallRule(job.panelPort);
    log('关闭 IPv6（实例改成纯 IPv4）');
    await disableIpv6();
    log('AWS 这边配置完成。服务器正在开 BBR、安装 3X-UI、建入站，装好后会自动打开面板并登录（约 2–3 分钟）。');
    await setStage('done');
    return true;
  }

  // ---------- 换 IP 任务（job.kind === 'newip'） ----------
  //
  //   locate   不知道实例在哪个区域时（旧记录），到首页的实例列表里找
  //   detach   解绑实例现在的静态 IP
  //   attach   新建一个静态 IP 挂上，记下新 IP
  //   release  删掉旧静态 IP。删不掉不影响节点，只提醒手动删（闲置的静态 IP 按小时收费）
  //   done     等新地址上的面板就绪（content.js）。证书由服务器上的 node-ip-watch 自己重签
  // 顺序是先让节点用上新 IP，再删旧的：删除那一步出问题也不会让节点停着

  // 去实例的页面。返回 false 表示页面要跳转或已经报错
  async function gotoInstance() {
    if (onInstancePage(job.name)) return true;
    var target = networkingUrl(job.name, job.region);
    if (!target || !once('to-instance')) { await fail('没能打开实例 ' + job.name + ' 的页面'); return false; }
    location.assign(target);
    return false;
  }

  async function stageLocate() {
    if (!/\/webapp\/home\/instances/.test(location.pathname)) {
      if (!once('to-home')) { await fail('没能打开 Lightsail 首页的实例列表'); return false; }
      location.assign(homeUrl('instances'));
      return false;
    }
    var re = new RegExp('/webapp/([a-z]{2}(?:-[a-z]+)+-\\d)/instances/' + encodeURIComponent(job.name) + '(?:/|$)');
    var region = null;
    var deadline = Date.now() + 60000;
    while (!region && Date.now() < deadline) {
      Array.prototype.forEach.call(document.querySelectorAll('a[href*="/instances/"]'), function (a) {
        var m = re.exec(new URL(a.href, location.href).pathname);
        if (m) region = m[1];
      });
      if (!region) await sleep(500);
    }
    if (!region) {
      await fail('在 Lightsail 首页的实例列表里没找到 ' + job.name + '。确认它还在当前登录的账号里，再点「重试」');
      return false;
    }
    log('实例 ' + job.name + ' 在 ' + region);
    await setStage('detach', { region: region, origin: location.origin });
    location.assign(networkingUrl(job.name, region));
    return false;
  }

  async function stageDetach() {
    if (!(await gotoInstance())) return false;
    if ((await instanceState(job.name, 60000)) === 'missing') {
      await fail('实例 ' + job.name + ' 不存在（可能已被删除），没法换 IP');
      return false;
    }
    await openNetworkingTab(job.name);
    if (document.querySelector(NET.detachStaticIp)) {
      var current = readStaticIp();
      if (current && current !== job.oldIp) {
        // 上次已经换好（重试时），或者在控制台里手动换过：不再换，直接用现在的 IP 更新记录
        if (current === job.ip) log('新静态 IP 已经挂上：' + current);
        else log('实例现在的静态 IP 是 ' + current + '，不是插件记录的 ' + job.oldIp + '（之前换过）。这次不再换，直接更新记录');
        await setStage('release', { ip: current, adopted: current !== job.ip });
        return true;
      }
      log('解绑旧静态 IP ' + job.oldIp + '（节点会断几分钟）');
      await detachStaticIp();
    }
    await setStage('attach');
    return true;
  }

  async function stageAttach() {
    if (!(await gotoInstance())) return false;
    await openNetworkingTab(job.name);
    if (!refreshCount()) log('新建并挂上静态 IP：' + job.newStaticIpName);
    var ip = await attachStaticIp(job.newStaticIpName, 25000);
    if (!ip) {
      var n = refreshCount() + 1;
      if (n > 24) {
        await fail('等了十几分钟，实例 ' + job.name + ' 的页面上一直不能挂静态 IP（页面显示的状态：' + (shownInstanceState() || '读不到') + '）。' +
          '到 Lightsail 里看一下这台实例是否正常，再点「重试」。');
        return false;
      }
      refreshCount(n);
      log('还不能挂静态 IP，刷新页面再试（第 ' + n + ' 次）');
      location.reload();
      return false;
    }
    if (ip === job.oldIp) {
      await fail('挂上的还是旧 IP ' + ip + '，没有换成。到 Lightsail 里看一下这台实例的静态 IP，再点「重试」');
      return false;
    }
    log('新 IP：' + ip);
    await setStage('release', { ip: ip });
    return true;
  }

  async function stageRelease() {
    if (job.adopted) {
      // 旧 IP 不是这次解绑的，可能已经挪给别的实例用了，不去动它
      log('插件记录里的旧 IP ' + job.oldIp + ' 不是这次解绑的，不去动它。如果它在 Lightsail → Networking 里闲置着，可以手动删掉。');
      await setStage('done');
      return true;
    }
    if (!onNetworkingHome()) {
      if (!once('to-networking-home')) {
        await setStage('done', { releaseWarning: '没能打开 Networking 页面删除旧静态 IP ' + job.oldIp });
        return true;
      }
      location.assign(homeUrl('networking'));
      return false;
    }
    log('删除旧静态 IP ' + job.oldIp);
    var warning = '';
    try {
      var result = await deleteStaticIp(job.oldIp);
      if (result === 'deleted') log('旧静态 IP 已删除');
      else log('Networking 页上没找到 ' + job.oldIp + '，可能已经删掉了');
      if (result !== 'deleted') warning = '没能确认旧静态 IP ' + job.oldIp + ' 已删除';
    } catch (e) {
      warning = e.message;
      log('旧静态 IP 没删掉：' + e.message);
    }
    if (warning) log('请到 Lightsail → Networking 确认没有闲置的静态 IP（闲置的按小时收费）。节点不受影响。');
    log('AWS 这边换好了。服务器发现 IP 变了会自动重签面板证书，约 1–3 分钟后新地址可用。');
    await setStage('done', { releaseWarning: warning });
    return true;
  }

  async function runNewIp() {
    if (job.stage === 'locate' && !(await stageLocate())) return;
    if (job.stage === 'detach' && !(await stageDetach())) return;
    if (job.stage === 'attach' && !(await stageAttach())) return;
    if (job.stage === 'release') await stageRelease();
  }

  async function run() {
    try {
      if (job.kind === 'newip') { await runNewIp(); return; }
      if (job.stage === 'check' && !(await stageCheck())) return;
      if (job.stage === 'fill' && !(await stageFill())) return;
      if (job.stage === 'network') await stageNetwork();
    } catch (e) {
      await fail(e.message);
    }
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window || !ev.data || ev.data.source !== 'lsn-ext') return;
    if (ev.data.type === 'job' && !started) {
      started = true;
      job = ev.data.data;
      if (job.blueprint) CONFIG.blueprint = job.blueprint;
      if (job.bundle) CONFIG.bundle = job.bundle;
      run();
    }
    if (ev.data.type === 'ack' && acks[ev.data.data]) { acks[ev.data.data](); delete acks[ev.data.data]; }
    if (ev.data.type === 'status') show(ev.data.data);
  });
  post('ready');
})();
