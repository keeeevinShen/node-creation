// 运行在 Lightsail 控制台页面上，是页面（page.js）和插件之间的传话人：
// 把当前部署任务交给 page.js 执行，把它回报的进度存进插件的存储，
// AWS 这边配置完后，每 10 秒让后台探一次 3X-UI 面板，就绪后请后台打开面板。
(async function () {
  'use strict';

  var me = await chrome.runtime.sendMessage({ type: 'whoami' });
  var job = (await chrome.storage.local.get('job')).job;
  // 只在插件自己打开的那个标签页里执行，出过错或已完成的任务不再自动跑
  if (!job || !me || job.tabId !== me.tabId || job.error || job.finished) return;

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function send(type, data) {
    window.postMessage({ source: 'lsn-ext', type: type, data: data }, location.origin);
  }

  // page.js 只需要这些；面板密码不交给页面（开机脚本里本来就含有，那个没法避免）
  function pageJob() {
    return {
      id: job.id, stage: job.stage, name: job.name, launchScript: job.launchScript,
      blueprint: job.blueprint, bundle: job.bundle,
      proxyPort: job.proxyPort, panelPort: job.panelPort,
      region: job.region || null, attempt: job.attempt || 0, step: job.step || 0,
      createClicked: !!job.createClicked
    };
  }

  // 存储的读-改-写排队执行，避免两条消息互相覆盖
  var queue = Promise.resolve();
  function change(fn) {
    queue = queue.then(async function () {
      var stored = (await chrome.storage.local.get('job')).job;
      if (!stored || stored.id !== job.id) return;
      fn(stored);
      job = stored;
      await chrome.storage.local.set({ job: stored });
    });
    return queue;
  }

  var waiting = false;
  async function waitPanel() {
    if (waiting) return;
    waiting = true;
    var okInARow = 0;
    for (var i = 0; i < 90; i++) {            // 最多等 15 分钟
      var result = null;
      try { result = await chrome.runtime.sendMessage({ type: 'checkPanel', id: job.id }); } catch (e) { /* 后台暂时没应答，下一轮再问 */ }
      // 连续两次都连得上才算就绪：面板装证书时会重启一次，入站也是在面板起来几秒后才建好
      okInARow = result && result.ok ? okInARow + 1 : 0;
      if (okInARow >= 2) {
        send('status', '3X-UI 已就绪，正在打开面板…');
        try { await chrome.runtime.sendMessage({ type: 'finish', id: job.id }); return; } catch (e) { okInARow = 0; }
      }
      await sleep(10000);
    }
    var msg = '等了 15 分钟，3X-UI 面板还没有就绪。点「重试」会继续等；想看原因，浏览器 SSH 进实例运行 sudo tail -n 50 /var/log/node-deploy.log。';
    send('status', '出错：' + msg);
    change(function (s) { s.log.push('出错：' + msg); s.error = msg; });
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window || !ev.data || ev.data.source !== 'lsn-page') return;
    var type = ev.data.type, data = ev.data.data;
    if (type === 'ready' && job.stage !== 'done') send('job', pageJob());
    if (type === 'log') change(function (s) { s.log.push(String(data)); });
    if (type === 'update') {
      var ack = ev.data.ack;
      change(function (s) { Object.assign(s, data); }).then(function () {
        if (ack) send('ack', ack);          // 告诉 page.js 已经存好，它才会跳转页面
        if (data && data.stage === 'done') waitPanel();
      });
    }
  });

  if (job.stage === 'done') waitPanel();
  else send('job', pageJob());
})();
