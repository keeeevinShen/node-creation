// 生成凭证、开机脚本和节点链接。弹窗（popup.js）和后台（background.js）共用，不碰页面。
var LSN = (function () {
  'use strict';

  // ---------- 可调参数 ----------
  var CONFIG = {
    xuiVersion: 'v3.11.0',          // 3X-UI 版本。开机脚本里的安装参数和 API 是按这个版本的文档写的
    // Xray 内核。3X-UI v3.11.0 自带 v26.10.21；Xray 从 v26.9.8 起，REALITY 服务端会拒绝握手里不带
    // X25519MLKEM768 的客户端（旧版小火箭、sing-box 内核的客户端等），服务器日志是
    // 「REALITY: processed invalid connection … authentication failed or validation criteria not met」。
    // v26.6.27 是最后一个新旧客户端都放行的版本，也是面板允许切换到的最低版本。
    xrayCompatVersion: 'v26.6.27',
    defaultXrayCore: 'compat',      // compat：装好面板后把内核换成 xrayCompatVersion；bundled：用面板自带的
    blueprint: 'debian_12',         // 系统镜像
    bundle: 'nano_3_0',             // 套餐：$5/月，512MB，带公网 IPv4
    defaultName: 'reality-node',
    defaultSni: 'aws.amazon.com',
    proxyPort: 443,
    waitStaticIpSeconds: 3600,      // 服务器开机后最多等多久静态 IP（中途出错、重试都算在内），之后才签面板证书
    // Lightsail 开放的区域。账号能不能用某个区，只有创建时才知道，不能用会在进度里显示 AWS 给的原因
    regions: [
      ['us-east-1', '美国 弗吉尼亚'], ['us-east-2', '美国 俄亥俄'], ['us-west-2', '美国 俄勒冈'],
      ['ca-central-1', '加拿大 中部'],
      ['ap-northeast-1', '日本 东京'], ['ap-northeast-2', '韩国 首尔'], ['ap-southeast-1', '新加坡'],
      ['ap-southeast-2', '澳大利亚 悉尼'], ['ap-southeast-3', '印尼 雅加达'], ['ap-south-1', '印度 孟买'],
      ['eu-central-1', '德国 法兰克福'], ['eu-west-1', '爱尔兰'], ['eu-west-2', '英国 伦敦'],
      ['eu-west-3', '法国 巴黎'], ['eu-north-1', '瑞典 斯德哥尔摩']
    ]
  };

  // ---------- 纯函数：生成凭证、开机脚本、链接 ----------

  function b64url(buf) {
    var bytes = new Uint8Array(buf), s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function randomString(len) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    var out = '', buf = new Uint8Array(len * 2);
    crypto.getRandomValues(buf);
    for (var i = 0; out.length < len; i++) {
      if (i >= buf.length) { crypto.getRandomValues(buf); i = 0; }
      // 丢掉会造成取模偏差的值
      if (buf[i] < 256 - (256 % chars.length)) out += chars[buf[i] % chars.length];
    }
    return out;
  }

  // 3X-UI 的订阅 ID：16 位小写字母和数字。客户端没有它，面板里就生成不了二维码和分享链接
  function randomSubId() {
    return randomString(48).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16);
  }

  function randomHex(bytes) {
    var buf = new Uint8Array(bytes), s = '';
    crypto.getRandomValues(buf);
    for (var i = 0; i < buf.length; i++) s += ('0' + buf[i].toString(16)).slice(-2);
    return s;
  }

  function randomPort() {
    var buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return 20000 + (buf[0] % 40000);
  }

  // 和面板里点「生成 Short ID」一样：8 个，长度 2–16 位各一个。
  // 16 位的固定放第一个：面板自己的分享链接和本插件的链接都用第一个
  function randomShortIds() {
    var rest = [1, 2, 3, 4, 5, 6, 7];
    for (var i = rest.length - 1; i > 0; i--) {
      var buf = new Uint32Array(1);
      crypto.getRandomValues(buf);
      var j = buf[0] % (i + 1), t = rest[i];
      rest[i] = rest[j];
      rest[j] = t;
    }
    return [randomHex(8)].concat(rest.map(randomHex));
  }

  // Reality 用的 X25519 密钥对，格式和 `xray x25519` 一样（32 字节，base64url，无填充）
  async function genX25519() {
    var kp = await crypto.subtle.generateKey({ name: 'X25519' }, true, ['deriveBits']);
    var pkcs8 = await crypto.subtle.exportKey('pkcs8', kp.privateKey);
    var raw = await crypto.subtle.exportKey('raw', kp.publicKey);
    return { priv: b64url(pkcs8.slice(-32)), pub: b64url(raw) };
  }

  // 面板给每个客户端算的 spiderX：'/' + sha256(spiderX种子 + '|' + subId) 的前 15 位十六进制
  // （3X-UI internal/sub/service.go 的 deriveSpiderX）。照着算，插件的链接就和面板导出的一样
  async function deriveSpiderX(seed, clientKey) {
    var digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(seed + '|' + clientKey));
    var bytes = new Uint8Array(digest), hex = '';
    for (var i = 0; i < bytes.length; i++) hex += ('0' + bytes[i].toString(16)).slice(-2);
    return '/' + hex.slice(0, 15);
  }

  async function genCredentials(name, sni, xrayCore) {
    var keys = await genX25519();
    var shortIds = randomShortIds();
    var subId = randomSubId();
    return {
      name: name,
      sni: sni,
      port: CONFIG.proxyPort,
      uuid: crypto.randomUUID(),
      priv: keys.priv,
      pub: keys.pub,
      shortId: shortIds[0],
      shortIds: shortIds,
      subId: subId,
      spx: await deriveSpiderX('/', subId),
      xrayCore: xrayCore === 'bundled' ? 'bundled' : (xrayCore === 'compat' ? 'compat' : CONFIG.defaultXrayCore),
      panelUser: randomString(10),
      panelPass: randomString(16),
      panelPort: randomPort(),
      panelPath: randomString(18)
    };
  }

  // 这次部署要换成的 Xray 版本；用面板自带内核时返回空
  function xrayPin(c) {
    return c.xrayCore === 'bundled' ? '' : CONFIG.xrayCompatVersion;
  }

  // 入站的 JSON，字段和 3X-UI v3.11.0 面板「添加入站 → VLESS + Reality」保存出来的一致
  // （对照面板源码的 vless-tcp-reality 样例），再加上 Sniffing。
  // Sniffing 一定要开：客户端本地 DNS 被污染时，交给节点的是假 IP，服务器照着连会超时；
  // 开了以后 Xray 从 TLS / HTTP / QUIC 握手里读出真实域名，在服务器上重新解析。
  // 不勾 Metadata Only 和 Route Only：勾了 Route Only 就只用于路由、不改目标地址，等于没开
  function buildInboundJson(c) {
    return JSON.stringify({
      enable: true,
      remark: c.name,
      listen: '',
      port: c.port,
      protocol: 'vless',
      expiryTime: 0,
      total: 0,
      settings: {
        clients: [{
          id: c.uuid, flow: 'xtls-rprx-vision', email: c.name, limitIp: 0, totalGB: 0, expiryTime: 0,
          enable: true, tgId: 0, subId: c.subId, comment: '', reset: 0
        }],
        decryption: 'none',
        encryption: 'none'
      },
      streamSettings: {
        network: 'tcp',
        tcpSettings: { acceptProxyProtocol: false, header: { type: 'none' } },
        security: 'reality',
        realitySettings: {
          show: false,
          xver: 0,
          target: c.sni + ':443',
          serverNames: [c.sni],
          privateKey: c.priv,
          minClientVer: '',
          maxClientVer: '',
          maxTimediff: 0,
          shortIds: c.shortIds || [c.shortId],
          mldsa65Seed: '',
          settings: { publicKey: c.pub, fingerprint: 'chrome', serverName: '', spiderX: '/', mldsa65Verify: '' }
        }
      },
      sniffing: { enabled: true, destOverride: ['http', 'tls', 'quic'] }
    }, null, 2);
  }

  // 服务器首次开机执行的脚本。Lightsail 用 /bin/sh（Debian 上是 dash）运行，只能用 POSIX sh 语法。
  // 所有插进去的值都是脚本自己生成的字母数字，或已用正则校验过的名字和域名。
  // Lightsail 的开机脚本上限是 16KB，注释写短一点。
  function buildLaunchScript(c) {
    var waitRounds = Math.ceil(CONFIG.waitStaticIpSeconds / 5);
    return [
      '#!/bin/sh',
      '# 由「Lightsail 一键节点」插件生成。日志：/var/log/node-deploy.log  结果：/root/node-deploy.status',
      ': >>/var/log/node-deploy.log; chmod 600 /var/log/node-deploy.log',
      'exec >>/var/log/node-deploy.log 2>&1',
      'set -u',
      'export HOME=/root',
      'status() { echo "$1" > /root/node-deploy.status; echo "== $(date -u +%H:%M:%S) $1"; }',
      'status "running"',
      "XRAY_PIN='" + xrayPin(c) + "'",
      "PROXY_PORT='" + c.port + "'",
      'warn=""',
      '',
      '# 1. BBR。默认的 cubic 一丢包就大幅降速，国内到海外的线路延迟高、会丢包，BBR 快很多。重启后仍生效',
      'echo tcp_bbr > /etc/modules-load.d/bbr.conf',
      "printf 'net.core.default_qdisc = fq\\nnet.ipv4.tcp_congestion_control = bbr\\n' > /etc/sysctl.d/99-bbr.conf",
      'modprobe tcp_bbr 2>/dev/null || true',
      'sysctl -p /etc/sysctl.d/99-bbr.conf || true',
      'cc=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null || true)',
      '[ "$cc" = "bbr" ] || warn="$warn bbr-not-enabled;"',
      '',
      '# 2. 依赖。等系统自带的自动更新释放 apt 锁，失败重试',
      'i=0',
      'while [ "$i" -lt 5 ]; do',
      '  i=$((i+1))',
      '  if apt-get -o DPkg::Lock::Timeout=300 -o Acquire::Retries=5 update -y \\',
      '    && apt-get -o DPkg::Lock::Timeout=300 -o Acquire::Retries=5 install -y curl ca-certificates unzip; then',
      '    break',
      '  fi',
      '  sleep 10',
      'done',
      '',
      '# 3. 等静态 IP 挂上。面板的 HTTPS 证书是签给公网 IP 的，挂静态 IP 会换 IP，所以要等换完再装',
      'pubip() {',
      '  curl -4 -fsS --max-time 5 https://api4.ipify.org 2>/dev/null \\',
      '    || curl -4 -fsS --max-time 5 https://ipv4.icanhazip.com 2>/dev/null || true',
      '}',
      'ip0=$(pubip | tr -d "[:space:]")',
      'echo "initial public ip: $ip0"',
      'n=0',
      'while [ "$n" -lt ' + waitRounds + ' ]; do',
      '  ip1=$(pubip | tr -d "[:space:]")',
      '  if [ -n "$ip1" ] && [ -n "$ip0" ] && [ "$ip1" != "$ip0" ]; then',
      '    echo "public ip changed to $ip1"',
      '    break',
      '  fi',
      '  n=$((n+1))',
      '  sleep 5',
      'done',
      'sleep 10',
      '',
      '# 4. 先把要换的 Xray 内核下载好，并核对官方 .dgst 里的 SHA2-256（和面板「切换 Xray 版本」做的一样）。',
      '#    提前下载，是为了面板装好后几秒内就能换完',
      'xzip=""',
      'xbin=""',
      'if [ -n "$XRAY_PIN" ]; then',
      '  case "$(uname -m)" in',
      '    x86_64|amd64) xarch=64; xbin=xray-linux-amd64 ;;',
      '    aarch64|arm64) xarch=arm64-v8a; xbin=xray-linux-arm64 ;;',
      '    *) xarch="" ;;',
      '  esac',
      '  url="https://github.com/XTLS/Xray-core/releases/download/$XRAY_PIN/Xray-linux-$xarch.zip"',
      '  i=0',
      '  while [ -n "$xarch" ] && [ "$i" -lt 5 ] && [ -z "$xzip" ]; do',
      '    i=$((i+1))',
      '    if curl -fsSL --connect-timeout 10 --max-time 180 --retry 3 -o /root/xray-pin.zip "$url" \\',
      '      && curl -fsSL --connect-timeout 10 --max-time 30 --retry 3 -o /root/xray-pin.dgst "$url.dgst"; then',
      "      want=$(sed -n 's/^SHA2-256= *//p' /root/xray-pin.dgst | tr -d '[:space:]' | tr 'A-F' 'a-f')",
      "      got=$(sha256sum /root/xray-pin.zip | cut -d' ' -f1)",
      '      if [ "${#want}" -eq 64 ] && [ "$want" = "$got" ]; then',
      '        xzip=/root/xray-pin.zip',
      '      else',
      '        echo "xray $XRAY_PIN checksum mismatch: want=$want got=$got"',
      '      fi',
      '    fi',
      '    [ -n "$xzip" ] || sleep 10',
      '  done',
      '  [ -n "$xzip" ] || warn="$warn xray-pin-download-failed;"',
      'fi',
      '',
      '# 5. 无人值守安装 3X-UI：账号、端口、路径由部署脚本指定，证书签给公网 IP（需要 80 端口）',
      'ok=""',
      'i=0',
      'while [ "$i" -lt 5 ]; do',
      '  i=$((i+1))',
      '  if curl -fsSL --connect-timeout 10 --max-time 60 --retry 5 -o /root/3x-ui-install.sh \\',
      '      https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh \\',
      '    && XUI_NONINTERACTIVE=1 XUI_ENABLE_FAIL2BAN=false XUI_SSL_MODE=ip \\',
      "       XUI_USERNAME='" + c.panelUser + "' XUI_PASSWORD='" + c.panelPass + "' \\",
      "       XUI_PANEL_PORT='" + c.panelPort + "' XUI_WEB_BASE_PATH='" + c.panelPath + "' \\",
      '       timeout 900 bash /root/3x-ui-install.sh ' + CONFIG.xuiVersion + ' </dev/null \\',
      '    && [ -s /etc/x-ui/install-result.env ]; then',
      '    ok=1',
      '    break',
      '  fi',
      '  sleep 15',
      'done',
      'if [ -z "$ok" ]; then status "failed: 3x-ui install"; exit 1; fi',
      '. /etc/x-ui/install-result.env',
      'if [ -z "${XUI_API_TOKEN:-}" ]; then status "failed: no api token"; exit 1; fi',
      '',
      '# 调面板自己的 API（用安装时生成的 token，只在本机调用）。用法：api 路径 [curl 参数…]，成功返回 0',
      'api() {',
      '  _path="$1"; shift',
      '  for _scheme in https http; do',
      '    resp=$(curl -ksS --max-time 20 -X POST \\',
      '      "$_scheme://127.0.0.1:${XUI_PANEL_PORT}/${XUI_WEB_BASE_PATH}/panel/api/$_path" \\',
      '      -H "Authorization: Bearer ${XUI_API_TOKEN}" "$@" 2>&1) || true',
      '    echo "api $_path ($_scheme): $(printf \'%.160s\' "$resp")"',
      '    case "$resp" in *\'"success":true\'*|*\'"success": true\'*) return 0 ;; esac',
      '  done',
      '  return 1',
      '}',
      'restart_xray() { api server/restartXrayService || systemctl restart x-ui; }',
      'listening() { command -v ss >/dev/null 2>&1 || return 0; ss -ltn 2>/dev/null | grep -q ":$PROXY_PORT "; }',
      'wait_listening() {',
      '  n=0',
      '  while [ "$n" -lt 12 ]; do',
      '    listening && return 0',
      '    n=$((n+1))',
      '    sleep 5',
      '  done',
      '  return 1',
      '}',
      '',
      '# 6. 换内核：新文件放好后改名覆盖（原子替换），自带的留一份 .bundled，再让面板重启 Xray',
      'bindir=/usr/local/x-ui/bin',
      'swapped=""',
      'if [ -n "$xzip" ] && [ -x "$bindir/$xbin" ]; then',
      '  rm -rf /root/xray-pin',
      '  if unzip -o -q "$xzip" xray -d /root/xray-pin && chmod 755 /root/xray-pin/xray \\',
      '    && /root/xray-pin/xray version >/dev/null 2>&1 \\',
      '    && cp -p "$bindir/$xbin" "$bindir/$xbin.bundled" \\',
      '    && cp /root/xray-pin/xray "$bindir/.xray-pin.tmp" && mv -f "$bindir/.xray-pin.tmp" "$bindir/$xbin"; then',
      '    swapped=1',
      '    restart_xray',
      '  else',
      '    warn="$warn xray-pin-install-failed;"',
      '  fi',
      'elif [ -n "$xzip" ]; then',
      '  warn="$warn xray-binary-not-found;"',
      'fi',
      'rm -rf /root/xray-pin /root/xray-pin.zip /root/xray-pin.dgst',
      '',
      '# 7. 通过面板的 API 建 VLESS + Reality 入站（和在面板里点「添加入站」走的是同一个接口）',
      "(umask 077; cat > /root/reality-inbound.json) <<'INBOUND_JSON'",
      buildInboundJson(c),
      'INBOUND_JSON',
      'ok=""',
      'n=0',
      'while [ "$n" -lt 30 ] && [ -z "$ok" ]; do',
      '  n=$((n+1))',
      '  if api inbounds/add -H "Content-Type: application/json" --data-binary @/root/reality-inbound.json; then',
      '    ok=1',
      '  else',
      '    sleep 5',
      '  fi',
      'done',
      'rm -f /root/reality-inbound.json',
      'if [ -z "$ok" ]; then status "failed: add inbound"; exit 1; fi',
      '',
      '# 8. 确认 Xray 真的在节点端口上监听。换过内核还起不来，就换回面板自带的再试',
      'if ! wait_listening; then',
      '  restart_xray',
      '  if ! wait_listening && [ -n "$swapped" ]; then',
      '    echo "xray $XRAY_PIN is not listening on $PROXY_PORT, rolling back to the bundled core"',
      '    cp -p "$bindir/$xbin.bundled" "$bindir/.xray-pin.tmp" && mv -f "$bindir/.xray-pin.tmp" "$bindir/$xbin"',
      '    restart_xray',
      '    warn="$warn xray-pin-rolled-back;"',
      '    wait_listening || true',
      '  fi',
      'fi',
      'ver=$(ls "$bindir"/xray-linux-* 2>/dev/null | grep -v bundled | head -n 1)',
      '[ -z "$ver" ] || ver=$("$ver" version 2>/dev/null | head -n 1 | cut -d" " -f1-2)',
      'if ! listening; then status "failed: xray not listening on $PROXY_PORT ($ver;$warn)"; exit 1; fi',
      'if [ -n "$warn" ]; then status "ok with warnings:$warn $ver, $cc"; else status "ok: $ver, $cc"; fi',
      ''
    ].join('\n');
  }

  // 节点链接，参数和顺序跟 3X-UI 面板导出的一样。
  // support-x25519mlkem768=true 是面板也会带的提示：Mihomo 系客户端靠它在握手里带上 X25519MLKEM768，
  // 连新版 Xray（v26.9.8 起）必须有；不认识这个参数的客户端会忽略它
  function buildLink(c, ip) {
    return 'vless://' + c.uuid + '@' + ip + ':' + c.port +
      '?encryption=none&flow=xtls-rprx-vision&fp=chrome&pbk=' + c.pub +
      '&security=reality&sid=' + c.shortId + '&sni=' + c.sni +
      '&spx=' + encodeURIComponent(c.spx || '/') + '&support-x25519mlkem768=true&type=tcp#' + c.name;
  }

  // 给人看的内核说明，用在弹窗和节点卡片上
  function xrayCoreLabel(c) {
    return c && c.xrayCore === 'bundled' ? '面板自带的最新版' : '兼容版 ' + CONFIG.xrayCompatVersion;
  }

  function buildResultText(c, ip) {
    return [
      '节点：' + c.name,
      '',
      '节点链接：',
      buildLink(c, ip),
      '',
      '3X-UI 面板：https://' + ip + ':' + c.panelPort + '/' + c.panelPath,
      '用户名：' + c.panelUser,
      '密码：' + c.panelPass,
      '',
      '链接就是密码，不要发到公开的地方。'
    ].join('\n');
  }

  return { CONFIG: CONFIG, genCredentials: genCredentials, buildLaunchScript: buildLaunchScript,
    buildInboundJson: buildInboundJson, buildLink: buildLink, buildResultText: buildResultText,
    xrayCoreLabel: xrayCoreLabel };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = LSN;
