// 生成凭证、开机脚本和节点链接。弹窗（popup.js）和后台（background.js）共用，不碰页面。
var LSN = (function () {
  'use strict';

  // ---------- 可调参数 ----------
  var CONFIG = {
    xuiVersion: 'v3.11.0',          // 3X-UI 版本。开机脚本里的安装参数和 API 是按这个版本的文档写的
    blueprint: 'debian_12',         // 系统镜像
    bundle: 'nano_3_0',             // 套餐：$5/月，512MB，带公网 IPv4
    defaultName: 'reality-node',
    defaultSni: 'aws.amazon.com',
    proxyPort: 443,
    waitStaticIpSeconds: 3600,      // 服务器开机后最多等多久静态 IP（中途出错、重试都算在内），之后才签面板证书
    // Lightsail 开放的区域。账号能不能用某个区，只有创建时才知道，不能用会在进度里显示 AWS 给的原因
    regions: [
      ['us-east-1', '美国 弗吉尼亚'], ['us-east-2', '美国 俄亥俄'], ['us-west-2', '美国 俄勒冈'],
      ['ca-central-1', '加拿大 中部'],
      ['ap-northeast-1', '日本 东京'], ['ap-northeast-2', '韩国 首尔'], ['ap-southeast-1', '新加坡'],
      ['ap-southeast-2', '澳大利亚 悉尼'], ['ap-southeast-3', '印尼 雅加达'], ['ap-south-1', '印度 孟买'],
      ['eu-central-1', '德国 法兰克福'], ['eu-west-1', '爱尔兰'], ['eu-west-2', '英国 伦敦'],
      ['eu-west-3', '法国 巴黎'], ['eu-north-1', '瑞典 斯德哥尔摩']
    ]
  };

  // ---------- 纯函数：生成凭证、开机脚本、链接 ----------

  function b64url(buf) {
    var bytes = new Uint8Array(buf), s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function randomString(len) {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    var out = '', buf = new Uint8Array(len * 2);
    crypto.getRandomValues(buf);
    for (var i = 0; out.length < len; i++) {
      if (i >= buf.length) { crypto.getRandomValues(buf); i = 0; }
      // 丢掉会造成取模偏差的值
      if (buf[i] < 256 - (256 % chars.length)) out += chars[buf[i] % chars.length];
    }
    return out;
  }

  // 3X-UI 的订阅 ID：16 位小写字母和数字。客户端没有它，面板里就生成不了二维码和分享链接
  function randomSubId() {
    return randomString(48).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16);
  }

  function randomHex(bytes) {
    var buf = new Uint8Array(bytes), s = '';
    crypto.getRandomValues(buf);
    for (var i = 0; i < buf.length; i++) s += ('0' + buf[i].toString(16)).slice(-2);
    return s;
  }

  function randomPort() {
    var buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return 20000 + (buf[0] % 40000);
  }

  // Reality 用的 X25519 密钥对，格式和 `xray x25519` 一样（32 字节，base64url，无填充）
  async function genX25519() {
    var kp = await crypto.subtle.generateKey({ name: 'X25519' }, true, ['deriveBits']);
    var pkcs8 = await crypto.subtle.exportKey('pkcs8', kp.privateKey);
    var raw = await crypto.subtle.exportKey('raw', kp.publicKey);
    return { priv: b64url(pkcs8.slice(-32)), pub: b64url(raw) };
  }

  async function genCredentials(name, sni) {
    var keys = await genX25519();
    return {
      name: name,
      sni: sni,
      port: CONFIG.proxyPort,
      uuid: crypto.randomUUID(),
      priv: keys.priv,
      pub: keys.pub,
      shortId: randomHex(8),
      subId: randomSubId(),
      panelUser: randomString(10),
      panelPass: randomString(16),
      panelPort: randomPort(),
      panelPath: randomString(18)
    };
  }

  function buildInboundJson(c) {
    return JSON.stringify({
      enable: true,
      remark: c.name,
      listen: '',
      port: c.port,
      protocol: 'vless',
      expiryTime: 0,
      total: 0,
      settings: {
        clients: [{
          id: c.uuid, flow: 'xtls-rprx-vision', email: c.name, enable: true,
          subId: c.subId, limitIp: 0, totalGB: 0, expiryTime: 0, tgId: 0, comment: '', reset: 0
        }],
        decryption: 'none'
      },
      streamSettings: {
        network: 'tcp',
        security: 'reality',
        realitySettings: {
          show: false,
          xver: 0,
          dest: c.sni + ':443',
          target: c.sni + ':443',
          serverNames: [c.sni],
          privateKey: c.priv,
          shortIds: [c.shortId],
          settings: { publicKey: c.pub, fingerprint: 'chrome', serverName: '', spiderX: '/' }
        },
        tcpSettings: { acceptProxyProtocol: false, header: { type: 'none' } }
      },
      sniffing: { enabled: true, destOverride: ['http', 'tls', 'quic', 'fakedns'] }
    }, null, 2);
  }

  // 服务器首次开机执行的脚本。Lightsail 用 /bin/sh（Debian 上是 dash）运行，只能用 POSIX sh 语法。
  // 所有插进去的值都是脚本自己生成的字母数字，或已用正则校验过的名字和域名。
  function buildLaunchScript(c) {
    var waitRounds = Math.ceil(CONFIG.waitStaticIpSeconds / 5);
    return [
      '#!/bin/sh',
      '# 由「Lightsail 一键节点」插件生成。日志：/var/log/node-deploy.log  结果：/root/node-deploy.status',
      'exec >>/var/log/node-deploy.log 2>&1',
      'set -u',
      'export HOME=/root',
      'status() { echo "$1" > /root/node-deploy.status; echo "== $(date -u +%H:%M:%S) $1"; }',
      'status "running"',
      '',
      '# 1. 依赖。等系统自带的自动更新释放 apt 锁，失败重试',
      'i=0',
      'while [ "$i" -lt 5 ]; do',
      '  i=$((i+1))',
      '  if apt-get -o DPkg::Lock::Timeout=300 -o Acquire::Retries=5 update -y \\',
      '    && apt-get -o DPkg::Lock::Timeout=300 -o Acquire::Retries=5 install -y curl ca-certificates; then',
      '    break',
      '  fi',
      '  sleep 10',
      'done',
      '',
      '# 2. 等静态 IP 挂上。面板的 HTTPS 证书是签给公网 IP 的，挂静态 IP 会换 IP，所以要等换完再装',
      'pubip() {',
      '  curl -4 -fsS --max-time 5 https://api4.ipify.org 2>/dev/null \\',
      '    || curl -4 -fsS --max-time 5 https://ipv4.icanhazip.com 2>/dev/null || true',
      '}',
      'ip0=$(pubip | tr -d "[:space:]")',
      'echo "initial public ip: $ip0"',
      'n=0',
      'while [ "$n" -lt ' + waitRounds + ' ]; do',
      '  ip1=$(pubip | tr -d "[:space:]")',
      '  if [ -n "$ip1" ] && [ -n "$ip0" ] && [ "$ip1" != "$ip0" ]; then',
      '    echo "public ip changed to $ip1"',
      '    break',
      '  fi',
      '  n=$((n+1))',
      '  sleep 5',
      'done',
      'sleep 10',
      '',
      '# 3. 无人值守安装 3X-UI：账号、端口、路径由部署脚本指定，证书签给公网 IP（需要 80 端口）',
      'ok=""',
      'i=0',
      'while [ "$i" -lt 5 ]; do',
      '  i=$((i+1))',
      '  if curl -fsSL --connect-timeout 10 --max-time 60 --retry 5 -o /root/3x-ui-install.sh \\',
      '      https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh \\',
      '    && XUI_NONINTERACTIVE=1 XUI_ENABLE_FAIL2BAN=false XUI_SSL_MODE=ip \\',
      "       XUI_USERNAME='" + c.panelUser + "' XUI_PASSWORD='" + c.panelPass + "' \\",
      "       XUI_PANEL_PORT='" + c.panelPort + "' XUI_WEB_BASE_PATH='" + c.panelPath + "' \\",
      '       timeout 900 bash /root/3x-ui-install.sh ' + CONFIG.xuiVersion + ' </dev/null \\',
      '    && [ -s /etc/x-ui/install-result.env ]; then',
      '    ok=1',
      '    break',
      '  fi',
      '  sleep 15',
      'done',
      'if [ -z "$ok" ]; then status "failed: 3x-ui install"; exit 1; fi',
      '',
      '# 4. 通过面板自己的 API 建 VLESS + Reality 入站（用安装时生成的 API token，只在本机调用）',
      '. /etc/x-ui/install-result.env',
      'umask 077',
      "cat > /root/reality-inbound.json <<'INBOUND_JSON'",
      buildInboundJson(c),
      'INBOUND_JSON',
      'if [ -z "${XUI_API_TOKEN:-}" ]; then status "failed: no api token"; exit 1; fi',
      'ok=""',
      'n=0',
      'while [ "$n" -lt 30 ] && [ -z "$ok" ]; do',
      '  n=$((n+1))',
      '  for scheme in https http; do',
      '    resp=$(curl -ksS --max-time 15 -X POST \\',
      '      "$scheme://127.0.0.1:${XUI_PANEL_PORT}/${XUI_WEB_BASE_PATH}/panel/api/inbounds/add" \\',
      '      -H "Authorization: Bearer ${XUI_API_TOKEN}" -H "Content-Type: application/json" \\',
      '      --data-binary @/root/reality-inbound.json 2>&1) || true',
      '    echo "add inbound ($scheme): $resp"',
      '    case "$resp" in *\'"success":true\'*|*\'"success": true\'*) ok=1; break ;; esac',
      '  done',
      '  [ -n "$ok" ] || sleep 5',
      'done',
      'rm -f /root/reality-inbound.json',
      'if [ -z "$ok" ]; then status "failed: add inbound"; exit 1; fi',
      'status "ok"',
      ''
    ].join('\n');
  }

  function buildLink(c, ip) {
    return 'vless://' + c.uuid + '@' + ip + ':' + c.port +
      '?encryption=none&flow=xtls-rprx-vision&security=reality&sni=' + c.sni +
      '&fp=chrome&pbk=' + c.pub + '&sid=' + c.shortId + '&type=tcp#' + c.name;
  }

  function buildResultText(c, ip) {
    return [
      '节点：' + c.name,
      '',
      '节点链接：',
      buildLink(c, ip),
      '',
      '3X-UI 面板：https://' + ip + ':' + c.panelPort + '/' + c.panelPath,
      '用户名：' + c.panelUser,
      '密码：' + c.panelPass,
      '',
      '链接就是密码，不要发到公开的地方。'
    ].join('\n');
  }

  return { CONFIG: CONFIG, genCredentials: genCredentials, buildLaunchScript: buildLaunchScript,
    buildInboundJson: buildInboundJson, buildLink: buildLink, buildResultText: buildResultText };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = LSN;
