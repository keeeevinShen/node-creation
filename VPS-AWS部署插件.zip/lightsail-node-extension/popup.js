// 插件弹窗：发起部署、看进度、管理已部署的节点（打开面板、复制链接、更换 IP）。
(function () {
  'use strict';

  var GENERIC_URL = 'https://lightsail.aws.amazon.com/ls/webapp/create/instance';
  var $ = function (id) { return document.getElementById(id); };

  function el(tag, text, className) {
    var node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function button(label, onClick, primary) {
    var b = el('button', label, primary ? 'primary' : '');
    b.type = 'button';
    b.addEventListener('click', onClick);
    return b;
  }

  // 控制台域名形如 123456789012-abcdefgh.us-east-2.console.aws.amazon.com，从里面取出账号和区域
  function parseHost(host) {
    var m = /^(\d{12})-[a-z0-9]+\.([a-z0-9-]+)\.console\.aws\.amazon\.com$/.exec(host);
    return m ? { host: host, account: m[1], region: m[2] } : null;
  }

  // 从已经打开的 AWS 控制台标签页里找出登录着的账号，最近用过的排前面
  async function detectAccounts() {
    var tabs = await chrome.tabs.query({ url: 'https://*.console.aws.amazon.com/*' });
    tabs.sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); });
    var seen = {}, list = [];
    tabs.forEach(function (tab) {
      var info = null;
      try { info = parseHost(new URL(tab.url).host); } catch (e) { /* 忽略 */ }
      if (info && !seen[info.host]) { seen[info.host] = true; list.push(info); }
    });
    return list;
  }

  function defaultName(nodes) {
    var used = nodes.map(function (n) { return n.name; });
    if (used.indexOf(LSN.CONFIG.defaultName) < 0) return LSN.CONFIG.defaultName;
    for (var i = 2; ; i++) {
      if (used.indexOf(LSN.CONFIG.defaultName + '-' + i) < 0) return LSN.CONFIG.defaultName + '-' + i;
    }
  }

  function renderRegions() {
    var select = $('region');
    select.textContent = '';
    var none = el('option', '不指定（用 AWS 控制台当前的区域）');
    none.value = '';
    select.appendChild(none);
    LSN.CONFIG.regions.forEach(function (r) {
      var option = el('option', r[1] + '（' + r[0] + '）');
      option.value = r[0];
      select.appendChild(option);
    });
  }

  // 区域默认跟着所选账号标签页的区域走；列表里没有这个区时选「不指定」
  function syncRegion() {
    var host = $('account').value;
    var select = $('region');
    select.value = host ? parseHost(host).region : '';
    if (select.selectedIndex < 0) select.value = '';
  }

  async function renderForm(nodes) {
    var select = $('account');
    select.textContent = '';
    (await detectAccounts()).forEach(function (info) {
      var option = el('option', '账号 ' + info.account + ' · ' + info.region);
      option.value = info.host;
      select.appendChild(option);
    });
    var generic = el('option', select.options.length ? '让 AWS 决定（最近登录的账号）' : '最近登录的账号（没有检测到打开的 AWS 标签页）');
    generic.value = '';
    select.appendChild(generic);
    renderRegions();
    syncRegion();
    $('name').value = defaultName(nodes);
    $('sni').value = LSN.CONFIG.defaultSni;
    renderXray();
  }

  // Xray 内核的选择。新版 Xray（v26.9.8 起）只放行握手里带 X25519MLKEM768 的客户端，
  // 旧版小火箭、sing-box 内核的客户端（含部分版本的 Hiddify）会被拒绝，所以默认换成兼容版
  var XRAY_HINTS = {
    compat: '装好面板后把内核换成 ' + LSN.CONFIG.xrayCompatVersion + '：新旧客户端都能连。以后想换回新版，在面板首页的 Xray 版本里切换。',
    bundled: '用 3X-UI 自带的最新内核：只有握手里带 X25519MLKEM768 的新客户端能连，握手里不带的会一直连不上（旧版小火箭、部分版本的 Hiddify 等）。'
  };

  function renderXray() {
    var select = $('xray');
    select.textContent = '';
    var compat = el('option', '兼容版 ' + LSN.CONFIG.xrayCompatVersion + '（推荐）');
    compat.value = 'compat';
    select.appendChild(compat);
    var bundled = el('option', '面板自带的最新版');
    bundled.value = 'bundled';
    select.appendChild(bundled);
    select.value = LSN.CONFIG.defaultXrayCore;
    syncXrayHint();
  }

  function syncXrayHint() {
    $('xray-hint').textContent = XRAY_HINTS[$('xray').value] || '';
  }

  // 第一次跳转的地址。知道区域时直接打开这个名字的实例页面（先查重名）；
  // 不知道账号时打开创建页，由 AWS 决定账号，有区域就带上 ?region=
  function firstUrl(host, region, name) {
    if (host) return 'https://' + host + '/lightsail/webapp/' + region + '/instances/' + encodeURIComponent(name) + '/networking';
    if (region) return GENERIC_URL + '?region=' + region;
    return GENERIC_URL;
  }

  async function start() {
    var name = $('name').value.trim(), sni = $('sni').value.trim(), host = $('account').value;
    var region = $('region').value;
    if (!region && host) region = parseHost(host).region;
    var error = $('form-error');
    error.textContent = '';
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(name)) { error.textContent = '节点名只能用字母、数字、- 和 _，并以字母或数字开头'; return; }
    if (!/^[A-Za-z0-9.-]+$/.test(sni)) { error.textContent = '伪装网站要是一个域名，比如 aws.amazon.com'; return; }
    $('start').disabled = true;
    try {
      var creds = await LSN.genCredentials(name, sni, $('xray').value);
      var job = {
        id: crypto.randomUUID(),
        name: name,
        host: host,
        region: region || null,
        url: firstUrl(host, region, name),
        stage: 'check',
        creds: creds,
        launchScript: LSN.buildLaunchScript(creds),
        blueprint: LSN.CONFIG.blueprint,
        bundle: LSN.CONFIG.bundle,
        proxyPort: creds.port,
        panelPort: creds.panelPort,
        log: ['已打开 Lightsail 控制台。如果看到的是 AWS 登录页，登录后会自动继续。'],
        createdAt: Date.now()
      };
      await chrome.runtime.sendMessage({ type: 'start', job: job });   // 新标签页打开后弹窗会自己关掉
    } catch (e) {
      error.textContent = '出错：' + e.message;
      $('start').disabled = false;
    }
  }

  function renderJob(job) {
    var newIp = job.kind === 'newip';
    var title = newIp ? (job.error ? '换 IP 中断：' : '正在换 IP：') : (job.error ? '部署中断：' : '正在部署：');
    $('job-title').textContent = title + job.name;
    var logBox = $('job-log');
    logBox.textContent = job.log.slice(-14).join('\n');
    logBox.scrollTop = logBox.scrollHeight;
    var actions = $('job-actions');
    actions.textContent = '';
    // 出错时是「重试」；没出错时也留一个「继续」，部署用的标签页被关掉或卡住时点它
    actions.appendChild(button(job.error ? '重试' : '继续', function () { chrome.runtime.sendMessage({ type: 'retry' }); }, !!job.error));
    var retryHint = newIp
      ? '重试会从停下的地方接着做：已经挂上新 IP 的话不会再换一次。'
      : '重试会从停下的地方接着做：先查实例有没有建好，建好了就接着配置，不会重复创建。';
    actions.appendChild(el('div', job.error
      ? retryHint
      : '正常情况下不用管。用的标签页被关掉了，或者很久没动静，点「继续」会从当前这一步接着做。', 'hint'));
    actions.appendChild(button(newIp ? '放弃这次换 IP' : '放弃这次部署', async function () {
      var text = newIp
        ? '只是让插件忘掉这次换 IP，AWS 上已经做了的改动不会撤回，插件里的节点记录也不会更新。继续吗？'
        : '只是让插件忘掉这次部署，AWS 上已经建好的实例和静态 IP 不会被删除，需要的话请到 Lightsail 控制台手动删。继续吗？';
      if (!confirm(text)) return;
      await chrome.storage.local.remove('job');
    }));
  }

  // 新静态 IP 的名字：节点名-ip-年月日时分，和旧的不重名
  function newStaticIpName(name) {
    var d = new Date();
    var pad = function (n) { return ('0' + n).slice(-2); };
    return name + '-ip-' + String(d.getFullYear()).slice(-2) + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes());
  }

  // 「更换 IP」：确认后开一个换 IP 任务。区域和控制台域名用记录里的；旧记录没有区域时，到首页的实例列表里找
  async function changeIp(node) {
    var text = '给 ' + node.name + ' 换一个新的公网 IP：\n\n' +
      '· 旧 IP ' + node.ip + ' 会被删除，找不回来\n' +
      '· 节点会断几分钟。换完后把新链接导入客户端，删掉旧节点\n';
    if (!node.ipWatch) {
      text += '\n这个节点是 0.8.0 之前的插件部署的：换之前要先点「复制服务器命令」，' +
        '到 Lightsail 里用浏览器 SSH 连上实例，粘贴运行一次。否则换完后面板打不开。\n';
    }
    if (!confirm(text + '\n继续吗？')) return;
    var info = node.host ? parseHost(node.host) : null;
    var region = node.region || (info ? info.region : '');
    var origin = node.origin || (node.host ? 'https://' + node.host : '');
    var url;
    if (region && origin) url = origin + '/lightsail/webapp/' + region + '/instances/' + encodeURIComponent(node.name) + '/networking';
    else if (origin) url = origin + '/lightsail/webapp/home/instances';
    else url = 'https://lightsail.aws.amazon.com/ls/webapp/home/instances';
    var panel = new URL(node.panelUrl);
    var job = {
      id: crypto.randomUUID(),
      kind: 'newip',
      name: node.name,
      host: node.host || '',
      region: region || null,
      origin: origin,
      url: url,
      stage: region && origin ? 'detach' : 'locate',
      oldIp: node.ip,
      newStaticIpName: newStaticIpName(node.name),
      panelPort: Number(panel.port),
      panelPath: panel.pathname.replace(/^\/+|\/+$/g, ''),
      log: ['已打开 Lightsail 控制台。如果看到的是 AWS 登录页，登录后会自动继续。'],
      createdAt: Date.now()
    };
    await chrome.runtime.sendMessage({ type: 'start', job: job });
  }

  // busy：有部署或换 IP 正在进行，这时不能再开一个换 IP 任务
  function renderNodes(nodes, busy) {
    var list = $('node-list');
    list.textContent = '';
    nodes.slice().reverse().forEach(function (node) {
      var card = el('div', undefined, 'node');
      card.appendChild(el('strong', node.name + ' · ' + node.ip));
      if (node.xrayCore) card.appendChild(el('div', 'Xray 内核：' + LSN.xrayCoreLabel(node), 'hint'));
      if (node.releaseWarning) {
        card.appendChild(el('div', node.releaseWarning + '。请到 Lightsail → Networking 确认没有闲置的静态 IP（闲置的按小时收费）。', 'error'));
      }
      if (!node.ipWatch) {
        card.appendChild(el('div', '0.8.0 之前部署的节点：要先在服务器上运行一次「复制服务器命令」，才能一键换 IP。', 'hint'));
      }
      card.appendChild(button('打开面板', function () {
        chrome.runtime.sendMessage({ type: 'openPanel', name: node.name, ip: node.ip });
      }, true));
      card.appendChild(button('复制链接', function (ev) {
        navigator.clipboard.writeText(node.link).then(function () { ev.target.textContent = '已复制'; });
      }));
      var change = button('更换 IP', function () { changeIp(node); });
      change.disabled = !!busy;
      if (busy) change.title = '等当前的部署或换 IP 结束后再换';
      card.appendChild(change);
      card.appendChild(button('复制面板登录信息', function (ev) {
        var text = '面板：' + node.panelUrl + '\n用户名：' + node.panelUser + '\n密码：' + node.panelPass;
        navigator.clipboard.writeText(text).then(function () { ev.target.textContent = '已复制'; });
      }));
      if (!node.ipWatch) {
        card.appendChild(button('复制服务器命令', function (ev) {
          navigator.clipboard.writeText(LSN.buildIpWatchCommand()).then(function () { ev.target.textContent = '已复制'; });
        }));
      }
      card.appendChild(button('移除记录', async function () {
        if (!confirm('只从插件里移除 ' + node.name + ' 的记录（链接和面板密码会一起丢掉），不会删除 AWS 上的实例。继续吗？')) return;
        var rest = ((await chrome.storage.local.get('nodes')).nodes || []).filter(function (n) {
          return !(n.name === node.name && n.ip === node.ip);
        });
        await chrome.storage.local.set({ nodes: rest });
      }));
      list.appendChild(card);
    });
  }

  var formShown = false;
  async function render() {
    var stored = await chrome.storage.local.get(['job', 'nodes']);
    var job = stored.job || null, nodes = stored.nodes || [];
    var active = job && !job.finished;
    // 换 IP 完成后弹窗里留一条结果，点「知道了」才清掉
    var done = job && job.finished && job.kind === 'newip';
    $('notice').hidden = !done;
    if (done) $('notice-text').textContent = job.log[job.log.length - 1];
    $('job').hidden = !active;
    $('form').hidden = !!active;
    $('nodes').hidden = nodes.length === 0;
    if (active) { renderJob(job); formShown = false; }
    else if (!formShown) { formShown = true; $('start').disabled = false; await renderForm(nodes); }
    renderNodes(nodes, !!active);
  }

  $('start').addEventListener('click', start);
  $('notice-ok').addEventListener('click', function () { chrome.storage.local.remove('job'); });
  $('account').addEventListener('change', syncRegion);
  $('xray').addEventListener('change', syncXrayHint);
  chrome.storage.onChanged.addListener(render);
  render();
})();
