// 插件弹窗：发起部署、看进度、管理已部署的节点。
(function () {
  'use strict';

  var GENERIC_URL = 'https://lightsail.aws.amazon.com/ls/webapp/create/instance';
  var $ = function (id) { return document.getElementById(id); };

  function el(tag, text, className) {
    var node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function button(label, onClick, primary) {
    var b = el('button', label, primary ? 'primary' : '');
    b.type = 'button';
    b.addEventListener('click', onClick);
    return b;
  }

  // 控制台域名形如 123456789012-abcdefgh.us-east-2.console.aws.amazon.com，从里面取出账号和区域
  function parseHost(host) {
    var m = /^(\d{12})-[a-z0-9]+\.([a-z0-9-]+)\.console\.aws\.amazon\.com$/.exec(host);
    return m ? { host: host, account: m[1], region: m[2] } : null;
  }

  // 从已经打开的 AWS 控制台标签页里找出登录着的账号，最近用过的排前面
  async function detectAccounts() {
    var tabs = await chrome.tabs.query({ url: 'https://*.console.aws.amazon.com/*' });
    tabs.sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); });
    var seen = {}, list = [];
    tabs.forEach(function (tab) {
      var info = null;
      try { info = parseHost(new URL(tab.url).host); } catch (e) { /* 忽略 */ }
      if (info && !seen[info.host]) { seen[info.host] = true; list.push(info); }
    });
    return list;
  }

  function defaultName(nodes) {
    var used = nodes.map(function (n) { return n.name; });
    if (used.indexOf(LSN.CONFIG.defaultName) < 0) return LSN.CONFIG.defaultName;
    for (var i = 2; ; i++) {
      if (used.indexOf(LSN.CONFIG.defaultName + '-' + i) < 0) return LSN.CONFIG.defaultName + '-' + i;
    }
  }

  async function renderForm(nodes) {
    var select = $('account');
    select.textContent = '';
    (await detectAccounts()).forEach(function (info) {
      var option = el('option', '账号 ' + info.account + ' · ' + info.region);
      option.value = info.host;
      select.appendChild(option);
    });
    var generic = el('option', select.options.length ? '让 AWS 决定（最近登录的账号）' : '最近登录的账号（没有检测到打开的 AWS 标签页）');
    generic.value = '';
    select.appendChild(generic);
    $('name').value = defaultName(nodes);
    $('sni').value = LSN.CONFIG.defaultSni;
  }

  async function start() {
    var name = $('name').value.trim(), sni = $('sni').value.trim(), host = $('account').value;
    var error = $('form-error');
    error.textContent = '';
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(name)) { error.textContent = '节点名只能用字母、数字、- 和 _，并以字母或数字开头'; return; }
    if (!/^[A-Za-z0-9.-]+$/.test(sni)) { error.textContent = '伪装网站要是一个域名，比如 aws.amazon.com'; return; }
    $('start').disabled = true;
    try {
      var creds = await LSN.genCredentials(name, sni);
      var job = {
        id: crypto.randomUUID(),
        name: name,
        host: host,
        // 知道账号和区域时，直接打开这个名字的实例页面（先查重名）；不知道时打开创建页，由 AWS 决定账号
        url: host ? 'https://' + host + '/lightsail/webapp/' + parseHost(host).region + '/instances/' + encodeURIComponent(name) + '/networking' : GENERIC_URL,
        stage: 'check',
        creds: creds,
        launchScript: LSN.buildLaunchScript(creds),
        blueprint: LSN.CONFIG.blueprint,
        bundle: LSN.CONFIG.bundle,
        proxyPort: creds.port,
        panelPort: creds.panelPort,
        log: ['已打开 Lightsail 控制台。如果看到的是 AWS 登录页，登录后会自动继续。'],
        createdAt: Date.now()
      };
      await chrome.runtime.sendMessage({ type: 'start', job: job });   // 新标签页打开后弹窗会自己关掉
    } catch (e) {
      error.textContent = '出错：' + e.message;
      $('start').disabled = false;
    }
  }

  function renderJob(job) {
    $('job-title').textContent = (job.error ? '部署中断：' : '正在部署：') + job.name;
    var logBox = $('job-log');
    logBox.textContent = job.log.slice(-14).join('\n');
    logBox.scrollTop = logBox.scrollHeight;
    var actions = $('job-actions');
    actions.textContent = '';
    // 出错时是「重试」；没出错时也留一个「继续」，部署用的标签页被关掉或卡住时点它
    actions.appendChild(button(job.error ? '重试' : '继续', function () { chrome.runtime.sendMessage({ type: 'retry' }); }, !!job.error));
    actions.appendChild(el('div', job.error
      ? '重试会从停下的地方接着做：先查实例有没有建好，建好了就接着配置，不会重复创建。'
      : '正常情况下不用管。部署用的标签页被关掉了，或者很久没动静，点「继续」会从当前这一步接着做。', 'hint'));
    actions.appendChild(button('放弃这次部署', async function () {
      if (!confirm('只是让插件忘掉这次部署，AWS 上已经建好的实例和静态 IP 不会被删除，需要的话请到 Lightsail 控制台手动删。继续吗？')) return;
      await chrome.storage.local.remove('job');
    }));
  }

  function renderNodes(nodes) {
    var list = $('node-list');
    list.textContent = '';
    nodes.slice().reverse().forEach(function (node) {
      var card = el('div', undefined, 'node');
      card.appendChild(el('strong', node.name + ' · ' + node.ip));
      card.appendChild(button('打开面板', function () {
        chrome.runtime.sendMessage({ type: 'openPanel', name: node.name, ip: node.ip });
      }, true));
      card.appendChild(button('复制链接', function (ev) {
        navigator.clipboard.writeText(node.link).then(function () { ev.target.textContent = '已复制'; });
      }));
      card.appendChild(button('复制面板登录信息', function (ev) {
        var text = '面板：' + node.panelUrl + '\n用户名：' + node.panelUser + '\n密码：' + node.panelPass;
        navigator.clipboard.writeText(text).then(function () { ev.target.textContent = '已复制'; });
      }));
      card.appendChild(button('移除记录', async function () {
        if (!confirm('只从插件里移除 ' + node.name + ' 的记录（链接和面板密码会一起丢掉），不会删除 AWS 上的实例。继续吗？')) return;
        var rest = ((await chrome.storage.local.get('nodes')).nodes || []).filter(function (n) {
          return !(n.name === node.name && n.ip === node.ip);
        });
        await chrome.storage.local.set({ nodes: rest });
      }));
      list.appendChild(card);
    });
  }

  var formShown = false;
  async function render() {
    var stored = await chrome.storage.local.get(['job', 'nodes']);
    var job = stored.job || null, nodes = stored.nodes || [];
    var active = job && !job.finished;
    $('job').hidden = !active;
    $('form').hidden = !!active;
    $('nodes').hidden = nodes.length === 0;
    if (active) { renderJob(job); formShown = false; }
    else if (!formShown) { formShown = true; $('start').disabled = false; await renderForm(nodes); }
    renderNodes(nodes);
  }

  $('start').addEventListener('click', start);
  chrome.storage.onChanged.addListener(render);
  render();
})();
